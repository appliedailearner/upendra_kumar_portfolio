Career Navigation Excel Kit (Desktop Excel)

How to use (recommended):
1) START_HERE_Career_Navigation_Kit.xlsx
   - Follow the 7-day quick start.

2) 01_Baseline_Snapshot.xlsx (monthly)
   - Fill sections A–E. Keep inputs factual.
   - Watch completeness %. If it’s <75%, you are not ready to plan.

3) 02_Target_Spec_and_Proof.xlsx (quarterly)
   - Write a constrained destination and an ownership boundary.
   - Define proof requirements as showable artifacts and metrics.

4) 03_JD_to_Plan_Worksheet.xlsx (any time you pick a target role)
   - Paste the JD, extract pillars, map proof, and build the 12-week plan.

5) 04_90_Day_Execution_Loop_Tracker.xlsx (weekly)
   - Track deliverables, blockers, and feedback loops.
   - Review each Friday. If you did not ship, you must cut scope.

6) 05_Proof_Cards_Portfolio.xlsx (as you ship)
   - Convert outcomes into proof cards. Use the 2-minute script box.

7) 06_Drift_Scoreboard.xlsx (weekly)
   - Score 0–2 per item. Track the trend.
   - Two weeks under 10 means reset.

Input convention:
- Light blue cells are inputs.
- Dropdowns enforce allowed values.

Tip:
- Excel calculation should be set to Automatic (Formulas → Calculation Options → Automatic).
