# Glossary (Plain English)

- **TCO (Total Cost of Ownership):** The full cost to run a workload over time. Includes compute, storage, licensing, ops, and support.
- **Business case:** A decision document that combines cost story, risk, timeline, and benefits.
- **Wave 1:** First production tranche. Designed to prove approach and unblock Wave 2+.
- **PoE (Proof of Execution):** The evidence trail that shows the work happened and was accepted.
- **Landing zone:** The Azure foundation (identity, network, governance, security, operations) where apps run.
- **Readiness gates:** Pass/fail checks that must be true before cutover.
- **Dependency mapping:** Inbound/outbound flows between systems, including ports and protocols.
- **Azure Migrate:** Microsoft service to discover, assess, and migrate workloads into Azure.
- **Azure Accelerate:** Umbrella for Microsoft investments and guidance that can speed cloud and AI outcomes.
- **AMM (Azure Migrate and Modernize):** Partner-led offering focused on accelerating migration and modernization engagements.
- **Azure Innovate:** Partner-led offering focused on modernizing apps, data, and AI solutions.
- **Cloud Accelerate Factory:** Microsoft expert-assisted delivery support for eligible engagements.
