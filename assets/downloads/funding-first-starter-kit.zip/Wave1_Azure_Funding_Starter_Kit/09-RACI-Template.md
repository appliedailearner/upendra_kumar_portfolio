# RACI Template (Customer / Partner / Microsoft)

Use this to remove hidden assumptions. Keep the table **signed off** in the kickoff week.

Legend: **R** = Responsible, **A** = Accountable, **C** = Consulted, **I** = Informed

| Workstream | Customer | Partner | Microsoft (optional) | Notes |
|---|---|---|---|---|
| Executive sponsor + decision date | A/R | C | I | sponsor must attend exec readout |
| Access approvals (vCenter/Hyper-V, network, CMDB) | A/R | C | I | delays kill the timebox |
| Azure subscription / tenant readiness | A/R | C | I | ensure ownership is clear |
| Azure Migrate setup + discovery | C | A/R | I | partner runs tool; customer provides access |
| Assessment outputs + sizing | C | A/R | I | customer validates exceptions |
| Business case (TCO) assumptions | A/R | R | I | finance/licensing must sign assumptions |
| Dependency capture (in/out) | A/R | R | I | app owners must participate |
| Landing zone readiness gates | A/R | R | C | Microsoft can advise if engaged |
| Security baseline requirements | A/R | C | C | align early on logging/Defender/SIEM |
| Wave 1 plan + runbook | C | A/R | I | partner drafts, customer approves |
| Change approvals + cutover windows | A/R | C | I | define lead times |
| Executive readout + Go/No-Go | A/R | R | I | decision must be recorded |
| PoE evidence pack compilation | C | A/R | I | store in approved location |

