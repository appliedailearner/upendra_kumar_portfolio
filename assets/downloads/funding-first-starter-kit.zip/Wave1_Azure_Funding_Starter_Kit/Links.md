# Links (Official + High-Signal)

Keep this file updated. Use these links in customer deliverables.

## A) Funding and acceleration programs
- Azure Accelerate (overview): https://azure.microsoft.com/solutions/azure-accelerate
- Introducing Azure Accelerate (blog): https://azure.microsoft.com/blog/introducing-azure-accelerate-fueling-transformation-with-experts-and-investments-across-your-cloud-and-ai-journey/
- Partner view of Azure offerings: https://partner.microsoft.com/partnership/azure-offerings
- Cloud Accelerate Factory (partner collection): https://partner.microsoft.com/asset/collection/cloud-accelerate-factory
- Azure Migrate and Modernize + Azure Innovate partner resources: https://partner.microsoft.com/asset/collection/azure-migrate-and-modernize-partner-led-and-azure-innovate-resources
- Solution Assessments: https://partner.microsoft.com/licensing/solution-assessments
- ECIF (definition): https://onefinance.microsoftcrmportals.com/knowledgebase/article/KA-01248/en-us

## B) Azure Migrate (docs)
- Azure Migrate docs hub: https://learn.microsoft.com/azure/migrate/
- About Azure Migrate (overview): https://learn.microsoft.com/azure/migrate/migrate-services-overview
- Build a business case: https://learn.microsoft.com/azure/migrate/how-to-build-a-business-case
- Business case concepts and formulas: https://learn.microsoft.com/azure/migrate/concepts-business-case-calculation
- Import-based assessment (CSV): https://learn.microsoft.com/azure/migrate/tutorial-discover-import

## C) Cloud Adoption Framework and Landing Zones (official)
- What is an Azure landing zone: https://learn.microsoft.com/azure/cloud-adoption-framework/ready/landing-zone/
- Landing zone implementation options: https://learn.microsoft.com/azure/cloud-adoption-framework/ready/landing-zone/implementation-options
- Azure Architecture Center: https://learn.microsoft.com/azure/architecture/

## D) GitHub repositories (practical)
- Azure Landing Zones (Bicep): https://github.com/Azure/ALZ-Bicep
- Azure Landing Zones (Terraform): https://github.com/Azure/terraform-azurerm-caf-enterprise-scale
- Azure Verified Modules (Terraform): https://github.com/Azure/terraform-azurerm-avm

## E) Microsoft Learn (training)
- Migration and modernization learning hub: https://learn.microsoft.com/training/topics/azure-migration

## F) Videos (official or Microsoft-hosted)
- AMM overview (Azure Videos): https://learn.microsoft.com/shows/azure-videos/overview-simplify-your-cloud-migration-journey-with-the-azure-migration-and-modernization-program
- Cloud Accelerate Factory (Azure Essentials Show): https://learn.microsoft.com/shows/azure-essentials-show/expert-guidance-for-your-azure-projects

## G) This starter kit (cross references)
- Funding cheat sheet: `01-Funding-Program-CheatSheet.md`
- Decision pack template: `05-Wave1-Decision-Pack.md`
- PoE pack: `06-PoE-Evidence-Pack.md`
- Readiness gate checklist: `07-Landing-Zone-Readiness-Gate.md`
