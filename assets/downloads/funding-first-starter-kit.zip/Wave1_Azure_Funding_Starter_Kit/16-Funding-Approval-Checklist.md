# Funding / Co-Investment Approval Checklist (What Microsoft will ask for)

Funding and acceleration approvals vary by region and program. This checklist helps you show the **minimum clarity** that makes approvals easy.

## 1) Deal identity (must be consistent everywhere)
- Customer name (legal + common)
- Region / country
- Industry
- Partner name and partner contact
- Microsoft account team contact (Account Exec / CSA / ...)

## 2) Sponsor + decision clarity
- Who is the executive sponsor? (name/title)
- What is the decision date?
- What happens if the decision is delayed?

## 3) Scope clarity (Wave 1, not the whole world)
- Total estate size (directional)
- Wave 1 scope (systems/apps) and environments
- Out of scope list
- Target Azure services (directional)

## 4) Business outcomes (measurable)
Provide 2 to 3 outcomes like:
- “Deliver Wave 1 decision pack and schedule production cutover”
- “Reduce datacenter exit risk by migrating Wave 1 critical apps”
- “Baseline cost story with validated assumptions”

## 5) Customer commitment (this is where approvals fail)
Confirm in writing:
- access will be provided by [date]
- SMEs will attend workshops
- sponsor will attend executive readout

Use: `14-Access-and-Data-Request-Checklist.md`

## 6) Deliverables and PoE evidence
List deliverables and the proof you will store:
- inventory baseline -> exported list
- assessment outputs -> Azure Migrate reports
- business case -> memo/report
- dependencies -> inbound/outbound tables
- readiness gates -> pass/fail checklist
- wave plan -> runbook + cutover/rollback
- sponsor decision -> readout memo + acceptance email

PoE: `06-PoE-Evidence-Pack.md`

## 7) Timeline (timeboxed)
- Start date
- End date
- Weekly checkpoint cadence

## 8) Safe funding language (copy/paste)
"We will start with a Wave 1 Decision Pack in 2 to 4 weeks. If eligible, Microsoft programs may co-invest or provide expert assistance. Funding is not guaranteed. The decision pack will stand either way."

## Attachments (recommended)
- `03-Nomination-OnePager.md`
- `04-SOW-Template.md`
- `17-14Day-Delivery-Plan.md`

## Official entry points
- Azure Accelerate: https://azure.microsoft.com/solutions/azure-accelerate
- Azure offerings (partner): https://partner.microsoft.com/partnership/azure-offerings
- Cloud Accelerate Factory collection: https://partner.microsoft.com/asset/collection/cloud-accelerate-factory
