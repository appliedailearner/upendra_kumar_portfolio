# 14-Day Delivery Plan (Wave 1 Decision Pack)

Use this when the customer wants a fast, leadership-grade outcome.

**Assumption:** access is provided by Day 2. If not, move to a 3–4 week plan.

## Day-by-day plan

### Day 1: Kickoff + owners
- Confirm Wave 1 scope boundaries (in/out)
- Confirm decision date (exec readout slot)
- Confirm owners and SMEs
- Assign access checklist

**Outputs**
- Agreed calendar
- Single source of truth tracker (actions/risks)

### Day 2: Access confirmed
- Verify vCenter/Hyper-V access or exports delivered
- Deploy Azure Migrate appliance (if allowed)
- Validate outbound connectivity/proxy

**Outputs**
- Discovery running

### Day 3: Inventory baseline
- Build Wave 1 candidate list (top 10–30 systems)
- Identify missing fields and owners

**Outputs**
- Inventory baseline draft

### Day 4: Dependency pre-work
- Identify app owners for Wave 1
- Send dependency template and schedule clinic

**Outputs**
- Dependency clinic booked

### Day 5: First assessment outputs
- Review sizing and readiness issues from assessment
- Flag exceptions (unsupported OS, special licensing)

**Outputs**
- Assessment findings list

### Day 6: Business case assumptions workshop
- Lock assumptions for right-sizing, licensing, savings levers

**Outputs**
- Assumptions log

### Day 7: Draft cost story
- Draft cost drivers and sensitivity table
- Prepare early leadership narrative (no surprises later)

**Outputs**
- Business case draft

### Day 8: Dependency clinic
- Capture inbound/outbound flows, ports, critical tests

**Outputs**
- Dependency tables completed

### Day 9: Landing zone readiness gates workshop
- Pass/fail per gate item
- Agree owners and fix-by dates

**Outputs**
- Gates checklist completed

### Day 10: Wave 1 plan and runbook draft
- Cutover sequence
- Test plan
- Rollback plan

**Outputs**
- Runbook draft

### Day 11: Compile Decision Pack
- Executive summary
- Scope + approach per workload
- Gates summary
- Risks and actions

**Outputs**
- Decision pack v1

### Day 12: Internal review
- Quality check (is it decision-ready?)
- Ensure PoE evidence is indexed

**Outputs**
- Decision pack v2

### Day 13: Customer pre-read
- Share pre-read 24 hours before exec readout
- Confirm decision makers attendance

**Outputs**
- Pre-read sent

### Day 14: Executive readout + decision
- Run the 45-minute decision meeting
- Record Go/No-Go/conditions

**Outputs**
- Signed decision log
- PoE evidence pack complete

---

## Minimal artifacts you must deliver
- `05-Wave1-Decision-Pack.md`
- `07-Landing-Zone-Readiness-Gate.md`
- Runbook (cutover + rollback)
- `06-PoE-Evidence-Pack.md`
