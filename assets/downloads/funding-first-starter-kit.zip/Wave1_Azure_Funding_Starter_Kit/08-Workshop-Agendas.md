# Workshop Agendas (Templates)

These agendas are designed to make Wave 1 decisions fast.

## 0) Kickoff (60 minutes)
**Goal:** lock scope, owners, access, and the decision date.

**Attendees:** sponsor, project owner, infra lead, network, security, app owner (top 3 apps), partner lead.

**Agenda:**
- Confirm decision date and timebox (2–4 weeks)
- Confirm Wave 1 scope boundaries (what is in/out)
- Confirm access plan (who provides what, by when)
- Confirm workshop calendar and SME availability
- Confirm source of truth tracker (where risks/actions live)

**Outputs:**
- Approved engagement plan (`17-14Day-Delivery-Plan.md`)
- Access checklist assigned (`14-Access-and-Data-Request-Checklist.md`)

---

## 1) Wave 1 Discovery Workshop (90 minutes)
**Goal:** align scope and discovery inputs so assessment starts immediately.

**Attendees:** app owners, infra, network, security, CMDB owner.

**Agenda:**
- Business goals and constraints
- Wave 1 candidate list (top systems)
- Discovery method (Azure Migrate vs exports)
- Critical constraints (IP overlap, change windows, licensing)
- Dependency capture method (inbound/outbound)

**Outputs:**
- Confirmed Wave 1 list
- Discovery plan and owners
- Initial dependency backlog

---

## 2) TCO + Business Case Workshop (90 minutes)
**Goal:** agree assumptions and validation path for the cost story.

**Attendees:** sponsor delegate (finance), infra lead, licensing owner, partner architect.

**Agenda:**
- What cost baseline exists today (hardware, software, hosting, ops)
- Right-sizing strategy (what we will trust vs challenge)
- Licensing assumptions (Azure Hybrid Benefit, SQL licensing)
- Savings levers (Reservations/Savings Plan) and what is realistic
- Sensitivity: what changes the numbers most

**Outputs:**
- Assumptions log
- Business case draft review date

Official references:
- Build a business case: https://learn.microsoft.com/azure/migrate/how-to-build-a-business-case

---

## 3) Dependency Clinic (90 minutes)
**Goal:** capture inbound/outbound flows for Wave 1 so cutover is not guesswork.

**Attendees:** app owners, network, security, operations.

**Agenda:**
- Inbound flows (who calls us)
- Outbound flows (what we call)
- Ports/protocols (minimum)
- Test plan for critical flows
- Known hard-coded IPs and certificates

**Outputs:**
- Completed dependency template for Wave 1 (`15-Dependency-Capture-Template.md`)

---

## 4) Landing Zone Gate Workshop (120 minutes)
**Goal:** validate gates, gaps, and owners before Wave 1.

**Attendees:** identity, network, security, governance, operations.

**Agenda:**
- Identity baseline (MFA, PIM, break-glass)
- Network model + connectivity + DNS
- Policy baseline + tagging + exceptions
- Logging/monitoring baseline
- Backup + DR approach
- Change and incident process readiness

**Outputs:**
- Completed gate checklist with owners/dates (`07-Landing-Zone-Readiness-Gate.md`)

---

## 5) Executive Readout (45 minutes)
**Goal:** force Go/No-Go decision, capture conditions.

**Attendees:** sponsor + decision makers.

**Agenda:**
- Wave 1 scope and timeline
- Cost story and assumptions
- Readiness gates (Pass/Fail)
- Top risks and mitigations
- Decision + next steps

**Outputs:**
- Decision recorded
- Conditions + owners + dates
