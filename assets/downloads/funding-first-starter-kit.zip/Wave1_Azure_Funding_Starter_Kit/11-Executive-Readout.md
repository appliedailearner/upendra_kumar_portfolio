# Executive Readout (Memo Template)

**Title:** [CustomerName] Wave 1 Azure Migration Go/No-Go Readout
**Date:** [YYYY-MM-DD]
**Sponsor:** [Name]

---

## 1) Decision required (do not hide this)
Choose one:
- ✅ **Go** (approve Wave 1 scope + dates)
- ❌ **No-Go** (stop Wave 1 until blockers resolved)
- ⚠ **Go-with-conditions** (go, but only after conditions are met)

## 2) Wave 1 scope summary
- Systems: **[X]**
- Apps/services: **[Y]**
- Environments: [Dev/Test/Prod]
- Critical workloads: [Top 3]

## 3) Business case summary (directional)
What leadership needs to know:
- Primary Azure cost drivers: [Compute/Storage/Network/DB]
- Largest assumption that changes cost: [right-sizing/licensing/usage]
- Expected benefits: [cost, resilience, compliance, agility]

Supporting evidence:
- Azure Migrate business case report (where possible)

## 4) Readiness gates (Pass/Fail)
| Gate | Status | Owner | Fix-by date |
|---|---|---|---|
| Identity baseline | [Pass/Fail] | [name] | [date] |
| Network + DNS | [Pass/Fail] | [name] | [date] |
| Governance baseline | [Pass/Fail] | [name] | [date] |
| Operations readiness | [Pass/Fail] | [name] | [date] |

## 5) Top risks (ranked)
1. [Risk] -> [Mitigation]
2. [Risk] -> [Mitigation]
3. [Risk] -> [Mitigation]

## 6) Wave 1 plan (what will happen)
- Timeline: [dates]
- Cutover model: [phased / big bang]
- Rollback approach: [summary]
- Testing plan: [smoke + functional]

## 7) Recommendation
State one line:
- **Go**, because: [reason]
- **No-Go**, because: [blockers]
- **Go-with-conditions**, because: [conditions]

## 8) Decisions and actions (must be captured)
### Decision log
| Decision | Owner | Date | Notes |
|---|---|---|---|
| [Go/No-Go] | [Sponsor] | [YYYY-MM-DD] | |

### Action log
| Action | Owner | Due date | Status |
|---|---|---|---|
| [Fix gate item] | [name] | [date] | |

---

## Appendix (links)
- Wave 1 Decision Pack: `05-Wave1-Decision-Pack.md`
- Gates checklist: `07-Landing-Zone-Readiness-Gate.md`
- PoE pack: `06-PoE-Evidence-Pack.md`
