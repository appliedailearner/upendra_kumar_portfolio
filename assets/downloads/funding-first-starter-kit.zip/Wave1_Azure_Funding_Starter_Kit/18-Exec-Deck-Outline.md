# Executive Readout Deck Outline (8 slides)

If leadership only reads one thing, it is this deck.

## Slide 1: Decision
- Go / No-Go / Go-with-conditions
- Decision date
- Sponsor

## Slide 2: Why now
- Business driver
- What happens if we do nothing

## Slide 3: Wave 1 scope
- Count of servers/apps
- Critical workloads
- In-scope and out-of-scope

## Slide 4: Approach
- Rehost vs replatform split (simple chart)
- Target landing zone summary

## Slide 5: Cost story (directional)
- Top 3 drivers
- Assumptions that change cost
- Next step: refine during Wave 1 execution

## Slide 6: Readiness gates
- Pass/Fail table
- Failures + owners + fix-by dates

## Slide 7: Risks and dependencies
- Top 5 risks
- Top 5 dependency constraints

## Slide 8: Wave 1 plan
- Timeline
- Cutover approach
- Rollback approach
- Next decision points

## Appendix slides (optional)
- Azure Migrate assessment summary screenshots
- Dependency map highlights
- PoE evidence index
