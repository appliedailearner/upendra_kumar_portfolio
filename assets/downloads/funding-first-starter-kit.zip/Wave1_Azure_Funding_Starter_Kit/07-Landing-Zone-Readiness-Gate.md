# Landing Zone Readiness Gate (Wave 1)

Use this as a **pass/fail** checklist before migrating production workloads.

**Rule:** If a gate is FAIL, it becomes a Wave 1 condition with an owner and fix-by date.

---

## Gate checklist (copy into your tracker)

| Gate area | Gate item | Status (Pass/Fail) | Evidence (link/notes) | Owner | Fix-by date | Risk if FAIL |
|---|---|---|---|---|---|---|
| Identity | MFA + baseline access controls | | | | | |
| Identity | Privileged access (PIM/break-glass) | | | | | |
| Organization | Management group strategy | | | | | |
| Organization | Subscription strategy | | | | | |
| Network | Connectivity plan (VPN/ER) | | | | | |
| Network | DNS strategy (private DNS, forwarding) | | | | | |
| Network | Egress control (firewall/proxy) | | | | | |
| Governance | Baseline policy set + exception process | | | | | |
| Governance | Tagging standard (owner, cost center, env) | | | | | |
| Security | Defender/SIEM baseline (as required) | | | | | |
| Security | Backup + DR approach agreed | | | | | |
| Operations | Monitoring/logging baseline | | | | | |
| Operations | Change/incident process defined | | | | | |

---

## What “good” looks like (quick guidance)

### Identity
- **Pass** if: tenant ownership is clear, MFA is enforced, privileged roles are controlled, break-glass accounts exist and were tested.
- **Evidence:** IAM baseline doc, Conditional Access policy list, PIM configuration screenshot or exported policy.

### Resource organization
- **Pass** if: management groups and subscriptions are decided and documented, and RBAC aligns to teams.
- **Evidence:** management group diagram + subscription list.

### Network
- **Pass** if: hub-spoke or vWAN is decided, connectivity is approved, DNS is designed, and egress is controlled.
- **Evidence:** network diagram, IP plan, DNS design, firewall/proxy decision.

### Governance
- **Pass** if: baseline policy is applied, tagging exists, and exceptions have a process.
- **Evidence:** policy assignment list, tagging standard.

### Security
- **Pass** if: baseline controls are agreed, logging is defined, and backup is planned.
- **Evidence:** security baseline, Defender settings (if used), backup design.

### Operations
- **Pass** if: monitoring/logging is ready, and the change process can support cutovers.
- **Evidence:** ops runbook overview, escalation path.

---

## Reference links (official)
- What is an Azure landing zone: https://learn.microsoft.com/azure/cloud-adoption-framework/ready/landing-zone/
- Platform landing zone implementation options: https://learn.microsoft.com/azure/cloud-adoption-framework/ready/landing-zone/implementation-options
