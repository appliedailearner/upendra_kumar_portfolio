# Access and Data Request Checklist (Wave 1)

Use this on day 1. Access delays are the #1 reason Wave 1 assessments fail.

## 1) Minimum access (pick the method)
### Option A: Azure Migrate discovery (recommended)
Provide:
- Virtualization admin access: **vCenter** or **Hyper-V**
- Network permissions to deploy Azure Migrate appliance (VM)
- Outbound internet access (or proxy) from appliance

### Option B: Exports (when tooling is blocked)
Provide one of these:
- **RVTools export** (VMware)
- **CMDB export** (server/app list)
- Host inventory export from your tooling

---

## 2) Inventory data you must provide
- Server hostname + IP
- OS + version
- CPU/RAM/storage
- Environment (Dev/Test/Prod)
- Business owner and technical owner
- Criticality (High/Medium/Low)
- RPO/RTO target (if known)

---

## 3) Network and DNS inputs
- Current subnets and routing model
- Connectivity plan: VPN / ExpressRoute / none
- DNS ownership (internal/external)
- DNS forwarders and private DNS zones expectations
- Firewall/proxy constraints (approved vendors)
- Egress control requirement (must all outbound go through firewall/proxy?)
- IP overlap risks (on-prem vs Azure ranges)

---

## 4) Identity and security inputs
- Entra ID tenant readiness (who owns)
- MFA / Conditional Access baselines
- Privileged access approach (PIM/break-glass)
- Data classification tiers and constraints
- Required security tooling (Defender, SIEM, EDR)

---

## 5) Operations inputs
- Backup tooling and standards
- Patch management approach
- Monitoring/logging tools
- Change window availability (weekend/night)
- Incident escalation contacts

---

## 6) Application dependency inputs (Wave 1)
Provide at least for top Wave 1 apps:
- Upstream callers (users/apps)
- Downstream services (DB, SMTP, AD, APIs, file shares)
- Ports/protocols and any hard-coded IPs
- Certificates and expiry dates (if applicable)

Template: `15-Dependency-Capture-Template.md`

---

## 7) Approval checklist
Confirm these are approved:
- Running discovery tools in the environment
- Exporting inventory data
- Storing outputs in the approved location

---

## Output
When this checklist is complete, you should be able to:
- run Azure Migrate discovery/assessment (or produce a baseline via exports)
- build the Wave 1 candidate list
- schedule dependency clinic and readiness gate workshop
