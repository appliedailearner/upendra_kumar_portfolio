# QuickStart (Wave 1 Decision Pack)

## Outcome you are driving
In **2 to 4 weeks**, you will deliver a **Wave 1 Decision Pack** that answers:
- What are we migrating in Wave 1?
- What is the approach per workload (rehost / replatform / refactor / retire)?
- What is the cost story (TCO + business case) and what assumptions matter?
- What are the dependencies, risks, and **readiness gates**?
- What is the Wave 1 plan (timeline, cutover, rollback, testing)?
- What proof will exist (PoE Evidence Pack)?

This is not a “workshop series”. It is a **Go/No-Go package**.

## The three outputs that make this credible
1. **Azure Migrate outputs** (assessment + business case where possible)
2. **Landing Zone Readiness Gate** (pass/fail with owners)
3. **Wave 1 Runbook** (cutover + rollback + test plan)

## The fastest working flow (10 steps)
1. **Qualify** the deal (drivers, timeline, Wave 1 scope).
2. Choose the **entry offer**: assessment / pilot / landing zone readiness.
3. Pick the **acceleration path** (funding and/or Microsoft expert help).
4. Agree a **timebox** (2–4 weeks) and acceptance criteria.
5. Collect **inventory + performance + dependencies**.
6. Produce **assessment + business case** outputs.
7. Validate **Landing Zone readiness gates**.
8. Draft **Wave 1 plan + runbook**.
9. Run the **Executive Readout** (Go/No-Go with conditions).
10. Package the **PoE Evidence Pack** and close.

## Your minimum meeting plan (works in real projects)
- **Day 1 Kickoff (60 min):** confirm scope, access, owners, dates
- **Dependency Clinic (90 min):** inbound/outbound flows + ports + integrations
- **Gates Review (60 min):** landing zone readiness pass/fail + actions
- **Exec Readout (45 min):** decision + conditions + next steps

Use agendas in: `08-Workshop-Agendas.md`

## Common failure modes (avoid these)
- Trying to do “everything” in the assessment. You only need Wave 1 decisions.
- Missing customer access. Fix this on day 1 (use `14-Access-and-Data-Request-Checklist.md`).
- Dependency gaps. Capture inbound/outbound, not just “server talks to server”.
- No acceptance criteria. If “done” is unclear, the scope will grow forever.

## What to fill first (in this order)
1. `02-PreSales-Discovery-Questionnaire.md`
2. `03-Nomination-OnePager.md`
3. `04-SOW-Template.md`
4. `15-Dependency-Capture-Template.md`
5. `07-Landing-Zone-Readiness-Gate.md`
6. `05-Wave1-Decision-Pack.md`
7. `06-PoE-Evidence-Pack.md`

## External references (official)
See `Links.md` for Learn / Partner / GitHub / YouTube.
