# Risk + Issue Log (Template)

Use this log from day 1. It becomes the steering committee truth.

## Scoring
- **Impact:** 1 (low) to 5 (high)
- **Likelihood:** 1 (unlikely) to 5 (likely)
- **Score:** Impact x Likelihood

## Log
| ID | Type (Risk/Issue) | Description | Impact | Likelihood | Score | Mitigation / Next action | Owner | Due date | Status | Notes |
|---|---|---|---:|---:|---:|---|---|---|---|---|
| R-001 | Risk | Access not provided on time | 5 | 4 | 20 | sponsor confirms access owners by Day 2 | [name] | [date] | Open | |
| R-002 | Risk | Dependency gaps for Wave 1 | 5 | 3 | 15 | run dependency clinic in Week 2 | [name] | [date] | Open | |
| I-001 | Issue | VPN config blocked by firewall rules | 4 | - | - | open change request; define workaround | [name] | [date] | Open | |

## Common risks you should always add
- IP overlaps between on-prem and Azure networks
- Missing DNS and private endpoint strategy
- Change windows too small for data replication/cutover
- App owners not available for testing
- Landing zone gates not owned (governance, RBAC, policies)
