# Nomination One-Pager (Sponsor + Microsoft Ready)

Use this to align the customer sponsor and the Microsoft account team on a **timeboxed Wave 1 Decision Pack**.

> Keep it to **one page** when printed.

---

## Engagement name
**[CustomerName] Wave 1 Azure Migration Decision Pack**

## 1) Decision we need (be explicit)
By **[DecisionDate]**, customer leadership will decide:
- ✅ Go / ❌ No-Go / ⚠ Go-with-conditions
- Wave 1 scope and target dates
- Readiness gate remediation owners/dates

## 2) Why now (2–3 sentences)
[Describe the business driver and urgency: exit datacenter, compliance, cost, resilience, modernization...]

## 3) Scope (crystal clear)
- Total estate (if known): **[X servers]**, **[Y apps]**
- Wave 1 candidate: **[X servers]**, **[Y apps]**
- In-scope workloads (top priority list):
  - [Workload 1]
  - [Workload 2]
  - [Workload 3]
- Out of scope (no ambiguity):
  - [Out-of-scope item]
  - [Out-of-scope item]

## 4) Target outcomes (measurable)
- Deliver a **Wave 1 Decision Pack** with:
  - recommended strategy per workload (rehost/replatform/refactor/retire)
  - Azure Migrate assessment outputs (where possible)
  - business case summary (cost drivers + assumptions)
  - dependency capture for Wave 1
  - landing zone readiness gate (pass/fail with owners)
  - Wave 1 runbook (cutover + rollback)

## 5) Timeline (timeboxed)
- Week 1: access + discovery + initial inventory
- Week 2: assessment + business case draft
- Week 3: dependency clinic + readiness gates + wave plan
- Week 4: executive readout + finalize PoE pack

## 6) Roles and responsibilities (who must do what)
**Customer owns**
- provide access within **[X business days]**
- provide SMEs for workshops (apps, network, security)
- provide approvals (architecture + change)

**Partner owns**
- deliver the decision pack and all listed artifacts
- run workshops and maintain a single tracker
- prepare PoE evidence pack

**Microsoft (optional)**
- program guidance and eligibility validation
- expert help (Cloud Accelerate Factory) depending on scenario

## 7) Key risks (top 5)
1. Access delays
2. Dependency gaps
3. Landing zone readiness gaps
4. Change window constraints
5. App owner availability

## 8) Expected Azure consumption drivers (directional)
List services likely to be used (do not invent numbers):
- compute (VMs)
- storage
- networking/connectivity
- security baseline services
- databases (where applicable)

## 9) The Microsoft ask (clear and bounded)
Request Microsoft to:
- confirm the best Azure Accelerate path (investment and/or expert help)
- share the expected nomination steps for **[Region]**
- align on PoE expectations (what evidence must exist)

## Attachments
- Draft SOW: `04-SOW-Template.md`
- Access checklist: `14-Access-and-Data-Request-Checklist.md`
- PoE checklist: `06-PoE-Evidence-Pack.md`

## Contacts
- Customer sponsor: [Name, Title]
- Customer technical owner: [Name, Title]
- Partner lead: [Name, Title]
- Microsoft account team: [MicrosoftContact]
- Partner development manager: [PDM]
