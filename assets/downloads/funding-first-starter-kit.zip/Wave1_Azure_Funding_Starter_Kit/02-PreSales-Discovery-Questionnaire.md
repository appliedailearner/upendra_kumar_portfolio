# Pre-Sales Discovery Questionnaire (Wave 1)

Use this to qualify, size, and de-risk a Wave 1 Azure migration opportunity.

**Rule:** If you cannot answer these in 60 minutes, the customer is not ready for a Wave 1 date.

## A) Business drivers (5 min)
1. What business problem are we solving? (cost, agility, compliance, exit datacenter, M&A, end-of-life...)
2. Why now? What is the deadline/date driver?
3. Who is the executive sponsor and who signs? (name, title)
4. What is the definition of success for Wave 1? (2–3 measurable outcomes)
5. What are the non-negotiables? (country/region, data residency, outage window)

## B) Scope and estate shape (10 min)
1. Total estate size: servers, databases, applications
2. Wave 1 candidate size: systems, environments (Dev/Test/Prod)
3. Top 10 apps by business criticality
4. Current platform: VMware / Hyper-V / bare metal / other
5. Current OS and DB mix: Windows/Linux, SQL/Oracle/Postgres
6. Any mainframe, Citrix, SAP, big data, VDI? (flag early)

## C) Compliance and risk (10 min)
1. Regulatory constraints (PII, PCI, ISO, SOC, local regulator requirements)
2. Data classification tiers (public/internal/confidential/restricted)
3. Identity requirements (MFA, Conditional Access, PIM)
4. Encryption requirements (at rest, in transit, key ownership)
5. Audit and logging expectations (SIEM, retention)

## D) Connectivity and network reality (10 min)
1. On-prem to Azure connectivity: VPN / ExpressRoute / none yet
2. DNS ownership and design constraints (private DNS, forwarding)
3. Egress control: firewall/proxy requirements, approved vendors
4. East-west traffic sensitivity (latency, throughput)
5. Any IP overlaps between networks? (this breaks migrations)

## E) Dependency and integration (10 min)
1. Do we have CMDB? Is it accurate?
2. Do we have app diagrams or system context?
3. What are the key integrations per app? (AD, SMTP, file shares, SFTP, APIs)
4. Are there hard-coded IPs or legacy dependencies?
5. Are there batch jobs, schedulers, ETL, reports?

Use the template: `15-Dependency-Capture-Template.md`

## F) Operations and support model (5 min)
1. Who runs production today? (internal, vendor, MSP)
2. How are backups done? RPO/RTO targets?
3. Monitoring/logging tools in place?
4. Patch management approach?
5. Change process maturity and lead times?

## G) Commercials + procurement reality (5 min)
1. Who pays? (IT, business unit, shared)
2. Procurement constraints (vendor onboarding, MSA timelines)
3. Do they need a fixed price for Wave 1?
4. Preferred contract model (time & material / fixed)

## H) Funding and acceleration signals (2 min)
1. Are they open to Microsoft co-investment programs? (Yes/No)
2. Do they have a Microsoft account team engaged? (Yes/No)
3. Do they want a pilot before committing? (Yes/No)

Use: `01-Funding-Program-CheatSheet.md` and `16-Funding-Approval-Checklist.md`

---

## Outputs you must produce after discovery
- Filled nomination one-pager: `03-Nomination-OnePager.md`
- Draft timeboxed SOW: `04-SOW-Template.md`
- Access/data request: `14-Access-and-Data-Request-Checklist.md`
- First pass Wave 1 inventory table (top 10 systems)

## Common traps (avoid)
- “Wave 1 = everything important” (it is always too large)
- “Dependencies later” (dependencies are Wave 1)
- “We will build landing zone during migration” (gates first)

## References (official)
- Azure Migrate docs: https://learn.microsoft.com/azure/migrate/
- What is an Azure landing zone: https://learn.microsoft.com/azure/cloud-adoption-framework/ready/landing-zone/
