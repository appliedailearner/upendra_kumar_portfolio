# Wave 1 Decision Pack (Template + Checklist)

This document is the structure you deliver to leadership for a **Go/No-Go** decision.

**Target length:** 8 to 15 pages + appendices.

---

## 1) Executive Summary (1 page)
Paste this into the top of the readout deck.

### Decision
We recommend: **[Go / No-Go / Go-with-conditions]**

### Why now
[2 sentences. Business driver + urgency]

### Wave 1 scope
- **[X systems]** across **[Y apps]**, environments: [Dev/Test/Prod]
- Critical apps: [Top 3]
- Out of scope: [short list]

### Cost story (directional)
- Azure cost will be primarily driven by: [Compute, Storage, Network, Database]
- Biggest assumption that changes cost: [right-sizing / licensing / ...]

### Top risks (with mitigation)
1. [Risk] -> [Mitigation]
2. [Risk] -> [Mitigation]
3. [Risk] -> [Mitigation]

### Go conditions (if any)
- Must complete: [Gate item] by [date]
- Must confirm: [Dependency] by [date]

---

## 2) Scope and inventory (Wave 1)
Include a table like this:

| System | App/Service | Env | Approach | Criticality | RPO/RTO | Owner | Notes |
|---|---|---|---|---|---|---|---|
| [server/app] | [name] | Prod | Rehost | High | 4h/1h | [name] | [notes] |

---

## 3) Technical approach (what we are building)
### Landing zone summary
- Subscriptions + management groups: [summary]
- Identity model: [summary]
- Network model: [hub-spoke / vWAN]
- Egress control: [firewall/proxy]

### Migration approach per workload
For each system, state:
- method (agentless/agent-based, tooling)
- cutover strategy (big bang / phased)
- test strategy

---

## 4) Dependencies (Wave 1)
Do not ship Wave 1 without inbound/outbound.

| System | Inbound dependencies (source -> port/proto) | Outbound dependencies (dest -> port/proto) | Critical flows to test | Notes |
|---|---|---|---|---|
| [system] | [list] | [list] | [flows] | [notes] |

Template: `15-Dependency-Capture-Template.md`

---

## 5) Cost and business case
### What you must show
- Azure Migrate business case summary (where possible)
- right-sizing assumptions
- licensing assumptions (Azure Hybrid Benefit, SQL licensing)
- sensitivity (what changes cost most)

### Minimum table to include
| Cost driver | Baseline | Assumption | Risk if wrong |
|---|---|---|---|
| VM sizing | [current] | [right-size factor] | under/over spend |
| Storage | [TB] | [growth rate] | higher cost |
| Bandwidth | [GB/month] | [egress] | cost surprise |

Azure Migrate business case references:
- Build business case: https://learn.microsoft.com/azure/migrate/how-to-build-a-business-case
- Concepts: https://learn.microsoft.com/azure/migrate/concepts-business-case-calculation

---

## 6) Readiness gates (pass/fail)
List the gates and status.

| Gate | Status (Pass/Fail) | Owner | Fix-by date | Risk if not fixed |
|---|---|---|---|---|
| Identity baseline | Pass | [name] | - | - |
| Egress control | Fail | [name] | [date] | outbound not controlled |

Template: `07-Landing-Zone-Readiness-Gate.md`

---

## 7) Wave 1 plan + runbook
### Minimum plan elements
- migration schedule by system
- cutover sequence
- test plan (smoke + functional)
- rollback plan
- change approvals required

---

## 8) Risks and issues
Use a simple log.
Template: `10-Risk-Issue-Log.md`

---

## 9) Executive recommendation
End with a clear call:
- **Go** (with dates)
- **No-Go** (with the top blockers)
- **Go-with-conditions** (with gates and owners)

---

## 10) Appendices
- Azure Migrate reports/exports
- workshop notes
- PoE evidence index

PoE template: `06-PoE-Evidence-Pack.md`
