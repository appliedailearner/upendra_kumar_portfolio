# FinOps Guardrails (Wave 1)

These guardrails stop cost surprises after cutover.

## 1) Minimum tagging standard
Required tags for every resource group and workload:
- `Owner`
- `CostCenter`
- `Environment` (Dev/Test/Prod)
- `Application`

## 2) Budget and alert baselines
- Create a Wave 1 budget for the subscription
- Create spend thresholds (50%, 80%, 100%)
- Confirm who receives alerts (finance + ops)

## 3) Cost drivers you must watch
- VM sizes and uptime (24x7 vs schedule)
- Storage growth and backups
- Outbound data egress
- Database tiers and IOPS

## 4) Right-sizing rules
- Do not lift and shift “max size” from on-prem
- Apply conservative right-sizing first, then validate with performance evidence

## 5) Reservation / savings decisions (timing)
- Do not buy long-term commitments before the sizing stabilizes
- Consider after 30–60 days of production data

## 6) Change control for cost
Any change that increases spend should require:
- owner approval
- budget impact note
- rollback plan

## Output
Add this as an appendix in the Decision Pack.
