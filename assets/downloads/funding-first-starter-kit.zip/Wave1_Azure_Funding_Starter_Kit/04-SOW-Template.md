# Statement of Work (Template)

**Customer:** [CustomerName]
**Partner:** [PartnerName]
**Region:** [Region]
**Start date:** [YYYY-MM-DD]
**Duration:** [2–4 weeks]

---

## 1) Objective
Deliver a **Wave 1 Decision Pack** that enables leadership to approve (or stop) Wave 1 with confidence:
- scope + migration approach per workload
- cost story (TCO + key drivers + assumptions)
- dependencies (inbound/outbound)
- landing zone readiness gates (pass/fail)
- Wave 1 runbook (cutover + rollback)

---

## 2) In-scope deliverables (with acceptance)

### D1. Inventory baseline
**What you deliver:**
- Wave 1 candidate inventory table (systems, environment, criticality)
- High-level application grouping

**Acceptance criteria:**
- Sponsor confirms Wave 1 candidate list is correct enough to plan

### D2. Assessment outputs (Azure Migrate where possible)
**What you deliver:**
- Discovery/assessment outputs (or CSV import outputs)
- Key sizing notes and constraints

**Acceptance criteria:**
- Customer technical owner reviews sizing assumptions and flags exceptions

### D3. Business case summary
**What you deliver:**
- TCO story (drivers + assumptions + sensitivities)
- Cost guardrails for Wave 1

**Acceptance criteria:**
- Sponsor acknowledges cost drivers and assumptions in writing

### D4. Dependency capture (Wave 1)
**What you deliver:**
- Inbound/outbound dependency table per system
- Key integrations and “must test” flows

**Acceptance criteria:**
- App owners confirm critical dependencies are captured

### D5. Landing zone readiness gates
**What you deliver:**
- Gate checklist pass/fail
- Remediation actions with owners/dates

**Acceptance criteria:**
- Customer agrees the “must fix before cutover” list

### D6. Wave 1 migration plan + runbook
**What you deliver:**
- Wave schedule with cutover sequence
- Testing plan (functional + smoke)
- Rollback plan

**Acceptance criteria:**
- Customer operations / change owner confirms approach is feasible

### D7. Executive readout
**What you deliver:**
- Memo or deck that forces Go/No-Go decision

**Acceptance criteria:**
- Sponsor decision recorded (Go/No-Go/Go-with-conditions)

### D8. PoE Evidence Pack
**What you deliver:**
- Evidence index + stored artifacts

**Acceptance criteria:**
- Customer sponsor confirms pack is received and stored in approved location

---

## 3) Out-of-scope (examples)
- Production migration execution (unless separately contracted)
- 24x7 operations and hypercare (unless separately contracted)
- Full landing zone build (unless separately contracted)
- Application code changes (unless separately contracted)

---

## 4) Customer responsibilities (non-negotiable)
Customer will provide within **[X business days]**:
- access to virtualization platform (vCenter/Hyper-V) or discovery exports
- network information (subnets, firewall, DNS, proxies)
- app owner SMEs for workshops
- change and approval process requirements

Use the checklist: `14-Access-and-Data-Request-Checklist.md`

---

## 5) Partner responsibilities
- Deliver the artifacts listed in section 2
- Run workshops and document decisions
- Maintain a single source of truth tracker (risks, actions, owners)

---

## 6) Assumptions
- Customer provides access and SMEs on time
- Required tools are approved for use
- Security and compliance constraints are disclosed early

---

## 7) Delivery governance
- Weekly sponsor checkpoint
- Action log (owner, due date, status)
- Decision date is fixed (scope adjusts, date does not)

---

## 8) Evidence (PoE)
PoE checklist and file naming:
- `06-PoE-Evidence-Pack.md`

---

## 9) Commercials
[Insert pricing / funding notes / purchase order references]

---

## 10) Sign-off
Customer: ____________________  Date: ________
Partner: _____________________  Date: ________
