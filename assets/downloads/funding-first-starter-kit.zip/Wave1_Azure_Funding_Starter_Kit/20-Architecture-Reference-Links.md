# Architecture Reference Links (Official + Practical)

Use these in customer decks and solution designs. Prefer official sources.

## Azure Landing Zones (CAF)
- What is an Azure landing zone: https://learn.microsoft.com/azure/cloud-adoption-framework/ready/landing-zone/
- Platform landing zone implementation options: https://learn.microsoft.com/azure/cloud-adoption-framework/ready/landing-zone/implementation-options
- Landing zone design principles: https://learn.microsoft.com/azure/cloud-adoption-framework/ready/landing-zone/design-principles
- Deploy Azure landing zones (Architecture Center): https://learn.microsoft.com/azure/architecture/landing-zones/landing-zone-deploy

## IaC accelerators and code
- ALZ-Bicep (GitHub): https://github.com/Azure/ALZ-Bicep
- Azure Landing Zones documentation hub (GitHub): https://github.com/Azure/Azure-Landing-Zones
- ALZ accelerator docs: https://azure.github.io/Azure-Landing-Zones/accelerator/
- Terraform CAF enterprise-scale module: https://registry.terraform.io/modules/Azure/caf-enterprise-scale/azurerm/latest

## Azure Migrate (discovery, assessment, migration)
- Azure Migrate overview: https://learn.microsoft.com/azure/migrate/
- VMware discovery tutorial: https://learn.microsoft.com/azure/migrate/tutorial-discover-vmware?view=migrate
- Migrate VMware VMs (agentless): https://learn.microsoft.com/azure/migrate/tutorial-migrate-vmware?view=migrate
- Migrate VMware VMs (agent-based): https://learn.microsoft.com/azure/migrate/tutorial-migrate-vmware-agent?view=migrate

## Business case and planning
- Build a business case: https://learn.microsoft.com/azure/migrate/how-to-build-a-business-case
- Business case calculation concepts: https://learn.microsoft.com/azure/migrate/concepts-business-case-calculation

## Funding and acceleration
- Azure Accelerate: https://azure.microsoft.com/solutions/azure-accelerate
- Partner Azure offerings (Azure Accelerate entry): https://partner.microsoft.com/partnership/azure-offerings
- Cloud Accelerate Factory collection: https://partner.microsoft.com/asset/collection/cloud-accelerate-factory
- Solution Assessments: https://partner.microsoft.com/licensing/solution-assessments
