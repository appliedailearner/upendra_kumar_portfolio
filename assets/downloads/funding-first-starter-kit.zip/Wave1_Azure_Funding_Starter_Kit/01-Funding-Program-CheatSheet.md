# Funding and Acceleration Cheat Sheet (Microsoft + Partner)

This cheat sheet helps you choose the right **Microsoft co-investment** or **expert help** for an Azure migration opportunity.

## First, separate the two concepts
1) **Investment / funding**: Microsoft contributes value (funds, credits, partner benefits) to reduce customer risk and cost.
2) **Expert help**: Microsoft provides **no-cost deployment assistance** (Cloud Accelerate Factory). Not cash.

In practice, Azure Accelerate is the common umbrella that can include both. See: https://azure.microsoft.com/solutions/azure-accelerate

---

## The 4 levers you can pull (memorize this)
1. **Assessment lever** (prove the plan)
2. **Execution lever** (move workloads)
3. **Innovation lever** (modernize apps/data/AI)
4. **Adoption lever** (train + operationalize)

---

## Programs you will hear most often

### 1) Azure Accelerate (umbrella)
**Use when:** you need one front door for *planning -> implementation*.
- Official overview: https://azure.microsoft.com/solutions/azure-accelerate
- Partner view: https://partner.microsoft.com/partnership/azure-offerings

**Typical outcomes you pitch:**
- “We can start with a timeboxed Wave 1 Decision Pack.”
- “If eligible, Microsoft can co-invest to reduce time-to-value.”

**What you MUST NOT do:**
- Promise funding approvals.
- Assume every customer is eligible.

### 2) Azure Migrate and Modernize (AMM)
**Use when:** customer is committed to migrate and wants acceleration for Wave 1.
- Partner resources hub: https://partner.microsoft.com/asset/collection/azure-migrate-and-modernize-partner-led-and-azure-innovate-resources
- Partner news context: https://techcommunity.microsoft.com/blog/partnernews/get-started-with-azure-partner-led-offerings-azure-migrate-and-modernize-and-azu/4037912

**Typical partner deliverables:**
- Azure Migrate assessment + wave plan
- Migration runbook + cutover planning
- PoE evidence

### 3) Azure Innovate
**Use when:** the deal is modernization-first (apps, data, analytics, AI) and not only VM migration.
- Included under Azure Accelerate: https://azure.microsoft.com/solutions/azure-accelerate

**Typical partner deliverables:**
- Modernization PoC/pilot
- App modernization plan
- Data platform modernization plan

### 4) Solution Assessments (SAE)
**Use when:** leadership needs numbers before approving Wave 1.
- Partner entry point: https://partner.microsoft.com/licensing/solution-assessments

**Typical deliverable:**
- A decision pack with scope, cost story, risks, and recommended wave plan

### 5) ECIF (End Customer Investment Funds)
**Use when:** the blocker is people and adoption (skills, operating model, readiness).
- Definition/reference: https://onefinance.microsoftcrmportals.com/knowledgebase/article/KA-01248/en-us

**Typical deliverables:**
- Training workshops
- Adoption enablement
- Operating model readiness

### 6) Cloud Accelerate Factory (expert help)
**Use when:** you need to reduce delivery risk fast for landing zone/security/data/AI services.
- Partner collection: https://partner.microsoft.com/asset/collection/cloud-accelerate-factory

---

## How to pick in 30 seconds

| Customer signal | What you offer | Your goal | Best lever |
|---|---|---|---|
| “We need proof and numbers first” | Timeboxed assessment + decision pack | Create Go/No-Go | Solution Assessment + Azure Migrate business case |
| “We are migrating now” | Wave 1 plan + execution support | Move Wave 1 | AMM + Cloud Accelerate Factory |
| “We want modernization/AI outcomes” | Pilot + modernization plan | Expand scope | Azure Innovate |
| “Teams are not ready” | Enablement + adoption workshops | Remove friction | ECIF |

---

## What Microsoft typically asks you for (minimum)
Use `16-Funding-Approval-Checklist.md`.

- Who is the customer sponsor?
- What is Wave 1 scope and timeline?
- What measurable outcomes will be delivered?
- What is the customer commitment (access, SMEs, approvals)?
- How will PoE evidence be produced?

---

## The safe talk track (use this verbatim)
"We will start with a 2 to 4 week Wave 1 Decision Pack. If eligible, Microsoft co-investment and/or expert help can accelerate delivery. Funding is not guaranteed, but the decision pack will stand either way."

---

## Related documents in this kit
- Discovery: `02-PreSales-Discovery-Questionnaire.md`
- Nomination: `03-Nomination-OnePager.md`
- SOW: `04-SOW-Template.md`
- Delivery plan: `17-14Day-Delivery-Plan.md`
- PoE: `06-PoE-Evidence-Pack.md`
- Links: `Links.md`
