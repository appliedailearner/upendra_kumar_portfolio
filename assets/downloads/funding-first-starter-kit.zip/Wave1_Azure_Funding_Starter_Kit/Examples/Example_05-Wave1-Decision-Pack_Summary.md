# Example (Filled): Wave 1 Decision Pack Summary

## Executive decision
**Recommendation:** Proceed with Wave 1 (30 servers, 12 apps) using a rehost-first approach for speed, plus targeted replatform for 2 apps.

## Why now
- Current infra risk (aging hardware + backup gaps)
- Compliance requirements better met with standardized landing zone controls

## Cost and savings (headline)
- Business case shows savings driven by right-sizing + reserved capacity planning (where applicable).
- Non-financial value: improved resiliency, faster recovery, stronger governance.

## Wave 1 plan
- Two migration sprints of 2 weeks each
- One cutover weekend per sprint

## Gating items (must be done before first cutover)
- Identity/PIM model approved
- Network egress and DNS approach finalized
- Monitoring + backup standards agreed

## Risks
- App owner availability
- Legacy OS versions

## Proof you will get (PoE)
- Signed Go/No-Go readout
- Runbook + rollback plan
- Evidence pack index
