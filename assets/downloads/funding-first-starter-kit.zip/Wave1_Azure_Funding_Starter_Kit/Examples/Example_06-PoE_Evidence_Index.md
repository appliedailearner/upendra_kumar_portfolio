# Example: PoE Evidence Index

| Evidence Item | File/Link | Owner | Date |
|---|---|---|---|
| Discovery inventory export | Inventory_Export.csv | Partner | YYYY-MM-DD |
| Azure Migrate assessment report | Assessment_Report.pdf | Partner | YYYY-MM-DD |
| Azure Migrate business case | Business_Case.pdf | Partner | YYYY-MM-DD |
| Landing zone readiness checklist | LZ_Readiness.md | Partner + Customer | YYYY-MM-DD |
| Executive Go/No-Go readout | Exec_Readout.pptx | Partner | YYYY-MM-DD |
| Wave 1 runbook | Wave1_Runbook.md | Partner | YYYY-MM-DD |
| Change approvals | CR_Approvals.pdf | Customer | YYYY-MM-DD |
