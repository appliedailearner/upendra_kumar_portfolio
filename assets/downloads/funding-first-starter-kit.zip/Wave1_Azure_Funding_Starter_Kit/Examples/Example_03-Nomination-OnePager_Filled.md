# Example (Filled): Nomination One-Pager

> This is a **fictional** example to show the level of detail that typically works.

## Customer snapshot
- **Customer:** UKLifeLabs (fictional)
- **Industry:** Healthcare diagnostics
- **Region:** UAE North (example)
- **Business goal:** Reduce datacenter risk and cost. Improve resiliency and security posture.
- **Decision deadline:** 14 calendar days

## Wave 1 scope (timeboxed)
- **Wave 1 apps:** 12
- **Wave 1 servers:** 30
- **Migration mix (Wave 1):** 70% rehost, 20% replatform, 10% retire

## Outcomes (measurable)
- Produce a Wave 1 **Go/No-Go** decision pack.
- Complete Azure Migrate discovery + assessment for Wave 1 scope.
- Produce Azure Migrate **Business Case** (TCO + savings).
- Confirm Landing Zone readiness gates (identity, network, policy, logging).

## Engagement type
- **Type:** Funded assessment / accelerated start
- **Duration:** 3 weeks

## Customer commitments
- Provide read-only access to virtualization platform or inventory export.
- Provide 2 SME hours per week (infra + security + app owner).
- Approve target region, network constraints, and identity approach.

## Delivery approach
- Week 1: inventory + discovery + dependency capture + kickoff
- Week 2: assessments + business case + landing zone readiness review
- Week 3: wave plan + runbook + exec readout

## Risks and mitigations
- **Risk:** Missing app owner inputs slows dependency mapping.
  - **Mitigation:** Weekly 45-min dependency clinic, strict cut-off date.

## Proof of execution (PoE) to produce
- Assessment exports, business case report, wave plan, exec readout, evidence index.
