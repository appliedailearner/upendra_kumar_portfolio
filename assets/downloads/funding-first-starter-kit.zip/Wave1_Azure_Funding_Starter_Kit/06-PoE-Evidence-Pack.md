# PoE Evidence Pack (Proof of Execution)

**Goal:** produce a simple, auditable package that proves what was delivered and accepted.

## What PoE is (in one sentence)
PoE is the **evidence trail** that shows the planned work happened, the customer reviewed it, and the outcomes are usable.

## The PoE pack structure
Keep these sections in order. Do not overcomplicate.

### A) Engagement metadata
- Signed SOW / statement of work
- Timeline and workshop calendar
- RACI (who owns what)
- Action log (risks, blockers, owners, due dates)

### B) Delivery evidence (minimum set)
- Inventory baseline (Wave 1 candidate list)
- Discovery evidence (exports, CMDB extract, RVTools, etc.)
- Azure Migrate assessment outputs (where possible)
- Azure Migrate business case summary (where possible)
- Dependency capture tables (inbound and outbound)
- Landing Zone readiness gate checklist (completed)
- Wave 1 plan + runbook (cutover + rollback)
- Executive readout memo/deck

### C) Acceptance evidence (must exist)
- Meeting minutes confirming review
- Email sign-off from sponsor, or approved change record

### D) Storage location
Store in a customer-approved location:
- SharePoint / Teams
- Customer Git repo
- Partner delivery repository (if allowed)

Avoid personal drives.

---

## PoE evidence index (use this table)
| Artifact | Owner | Format | Where stored | Acceptance proof | Notes |
|---|---|---|---|---|---|
| SOW signed | Customer + Partner | PDF | [link] | signature | |
| Inventory baseline | Partner | XLSX | [link] | email approval | |
| Azure Migrate assessment | Partner | PDF/Export | [link] | meeting notes | |
| Business case summary | Partner | PDF | [link] | sponsor email | |
| Dependencies table | Partner + App owners | XLSX | [link] | app owner confirmation | |
| Readiness gate checklist | Partner + Customer | MD/PDF | [link] | gates review MoM | |
| Wave 1 runbook | Partner | DOCX | [link] | ops approval | |
| Exec readout | Partner | PPTX | [link] | decision recorded | |

---

## File naming convention (copy/paste)
- 01_SOW_[CustomerName]_Wave1_DecisionPack_[YYYYMMDD].pdf
- 02_Inventory_Wave1_[YYYYMMDD].xlsx
- 03_AzureMigrate_Assessment_[YYYYMMDD].pdf
- 04_BusinessCase_[YYYYMMDD].pdf
- 05_Dependencies_Wave1_[YYYYMMDD].xlsx
- 06_LZ_Readiness_Gates_[YYYYMMDD].pdf
- 07_Wave1_Runbook_[YYYYMMDD].docx
- 08_Exec_Readout_[YYYYMMDD].pptx
- 09_Acceptance_Email_[YYYYMMDD].msg

---

## Related documents in this kit
- Decision pack: `05-Wave1-Decision-Pack.md`
- Readiness gates: `07-Landing-Zone-Readiness-Gate.md`
- Workshops: `08-Workshop-Agendas.md`
- Exec memo: `11-Executive-Readout.md`
