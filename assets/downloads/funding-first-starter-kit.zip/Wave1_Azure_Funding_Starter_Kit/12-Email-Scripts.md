# Email Scripts (Copy/Paste)

Use these to keep requests short, specific, and easy to approve.

---

## 1) Microsoft account team: align on Azure Accelerate path
**Subject:** [CustomerName] Wave 1 decision pack, request to align on Azure Accelerate options

Hi [MicrosoftContact],

We are preparing a timeboxed **Wave 1 Decision Pack** for [CustomerName] (scope: [X servers], [Y apps], decision date: [DecisionDate]).

Request:
1) Confirm the best Azure Accelerate path (investment programs vs expert help).
2) Share eligibility considerations for [Region] and the expected nomination steps.
3) Confirm PoE expectations for this engagement.

We can share a one-pager + draft SOW + access checklist today.

Thanks,
[YourName]

---

## 2) Microsoft account team: request Cloud Accelerate Factory support
**Subject:** [CustomerName] request for Cloud Accelerate Factory support (Wave 1)

Hi [MicrosoftContact],

We are executing a Wave 1 timebox for [CustomerName]. We would like to request **Cloud Accelerate Factory** support for:
- [Landing zone / network / security baseline / migration tooling]

Target timeframe: [start date] to [end date]

Attached:
- Nomination one-pager
- Draft delivery plan

Thanks,
[YourName]

---

## 3) Customer sponsor: access + SME checklist
**Subject:** [CustomerName] Wave 1 assessment, access and SME checklist

Hi [CustomerSponsor],

To deliver the Wave 1 decision pack in **[2–4 weeks]**, we need the following by **[date]**:
- Access items (vCenter/Hyper-V, network/DNS info, CMDB/export)  
- SME availability for workshops (apps, network, security)

Attached:
- Access and data request checklist
- Workshop calendar

Thanks,
[YourName]

---

## 4) Customer app owners: dependency clinic request
**Subject:** Wave 1 dependency clinic, inputs needed for [CustomerName]

Hi team,

We are capturing inbound/outbound dependencies for the Wave 1 cutover plan.

Please join the **Dependency Clinic** on [date/time]. Before the session, share:
- upstream callers (who calls the app)
- downstream services (what the app calls)
- ports/protocols and any hard-coded IPs

Template: `15-Dependency-Capture-Template.md`

Thanks,
[YourName]

---

## 5) Customer sponsor: Executive Readout scheduling
**Subject:** Wave 1 Go/No-Go decision meeting, [CustomerName]

Hi [CustomerSponsor],

We are ready to schedule the **Wave 1 Executive Readout**.

Proposed slot: [date/time]
Decision required: Go / No-Go / Go-with-conditions

Pre-read will be shared 24 hours before the meeting.

Thanks,
[YourName]

---

## 6) Internal partner team: scope control reminder
**Subject:** Wave 1 timebox rules, [CustomerName]

Team,

Reminder: this engagement is a **Wave 1 Decision Pack** in [2–4 weeks].

Non-negotiables:
- dependency capture must include inbound + outbound
- gates must be pass/fail with owners
- PoE evidence must be captured from day 1

If scope expands, we will trade scope for time. Decision date does not move.

[YourName]
