# Wave 1 Azure Migration Funding + Execution Starter Kit

Client-ready templates and checklists to turn an Azure migration opportunity into a **Wave 1 Go/No-Go decision**, with **Microsoft co-investment (where eligible)** and an execution-ready plan.

## What this kit helps you do
1. **Start fast** with a funded or accelerated assessment/pilot.
2. **Create decision clarity** (scope, cost, risk, readiness gates).
3. **Convert to delivery** (Wave 1 plan + runbook + PoE evidence).

## Who should use this
- Partner **Pre-sales Architect** (wins the deal)
- **Migration Architect** (makes it technically correct)
- **Project Manager** (keeps timebox + ownership tight)
- **Sponsor / Director** (forces Go/No-Go decisions)

## What you will deliver in 2 to 4 weeks
- **Wave 1 Decision Pack** (leadership-ready)
- **Landing Zone Readiness Gate** (pass/fail with owners)
- **Wave 1 Migration Plan + Runbook** (cutover + rollback)
- **PoE Evidence Pack** (auditable proof of delivery)

## How to use this kit (recommended sequence)
1. `00-QuickStart.md` (outcome + flow)
2. `17-14Day-Delivery-Plan.md` (day-by-day plan)
3. `02-PreSales-Discovery-Questionnaire.md` (qualify + scope)
4. `01-Funding-Program-CheatSheet.md` (choose the right lever)
5. `16-Funding-Approval-Checklist.md` (what Microsoft will ask for)
6. `14-Access-and-Data-Request-Checklist.md` (get access without delays)
7. `03-Nomination-OnePager.md` (Microsoft + sponsor-ready)
8. `04-SOW-Template.md` (timebox + acceptance)
9. `15-Dependency-Capture-Template.md` (inbound/outbound flows)
10. `07-Landing-Zone-Readiness-Gate.md` (gates + evidence)
11. `05-Wave1-Decision-Pack.md` (the final pack)
12. `11-Executive-Readout.md` + `18-Exec-Deck-Outline.md` (decision meeting)
13. `06-PoE-Evidence-Pack.md` (close clean)

## Placeholders
Replace tokens like `[CustomerName]`, `[PartnerName]`, `[MicrosoftContact]`, `[Region]`.

## Rules that keep this client-ready
- Funding and approvals **vary by region, customer type, and field priorities**. Never promise funding. Structure the ask.
- Always separate **funding** (investment) vs **expert help** (Cloud Accelerate Factory).
- Timebox aggressively. If you cannot finish in 4 weeks, your scope is wrong.
- Capture PoE evidence from day 1. Do not “rebuild evidence” at the end.

## Link library
All external links (Learn, Partner, GitHub, YouTube): `Links.md`

**Last updated:** 2026-01-16
