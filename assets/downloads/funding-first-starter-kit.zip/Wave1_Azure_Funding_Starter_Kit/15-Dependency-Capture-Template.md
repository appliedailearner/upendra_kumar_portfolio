# Dependency Capture Template (Inbound + Outbound)

This is the minimum dependency view you need before you cut over Wave 1.

**Rule:** “Server A depends on Server B” is not enough. Capture the *direction*, *port*, and *critical flows to test*.

## A) System context
| Field | Value |
|---|---|
| App/System name | |
| Environment | Dev / Test / Prod |
| Owner (Business) | |
| Owner (Technical) | |
| Criticality | High / Medium / Low |
| RPO/RTO | |

## B) Inbound dependencies (things that call THIS system)
| Source | Source type (user/app/server) | Protocol | Port | Auth (AD/cert/token) | Frequency | Critical? (Y/N) | Test method | Notes |
|---|---|---|---:|---|---|---|---|---|
|  |  | TCP | 443 |  |  | Y | smoke + functional |  |

## C) Outbound dependencies (things THIS system calls)
| Destination | Dest type (DB/API/SaaS/file) | Protocol | Port | Auth (AD/cert/token) | Frequency | Critical? (Y/N) | Test method | Notes |
|---|---|---|---:|---|---|---|---|---|
|  |  | TCP | 1433 |  |  | Y | query test |  |

## D) Data flows (what moves where)
| Flow | Data type | Sensitivity | Direction | Notes |
|---|---|---|---|---|
| App -> DB | customer records | Confidential | outbound | encryption required |

## E) “Breakers” list (capture these early)
- Hard-coded IP addresses
- Legacy TLS/cipher restrictions
- Certificates and expiry dates
- Non-standard ports
- Batch windows or schedulers
- On-prem file shares and printers
- External partner IP allowlists

## Output
Once complete, you can:
- define firewall rules and DNS requirements
- build cutover test checklist
- identify what must migrate together
