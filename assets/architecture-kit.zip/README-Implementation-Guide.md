# Architecture Kit: Two Doors, One Rulebook 🛡️

Thank you for downloading the "Secure AI Gateway" architecture kit.

## 📦 What's Included?
1.  **Architecture-Diagram.png**: Custom "Cyber Door" reference visual.
2.  **Official-Microsoft-Ref-Arch.png**: The official GenAI Gateway reference architecture.
3.  **APIM-Global-Policy.xml**: The exact Azure API Management policy code to implement this pattern.

## 🚀 How to Implement
1.  **Create an Azure API Management Instance.**
2.  **Copy the Policy:** Open `APIM-Global-Policy.xml` and copy the contents.
3.  **Apply to Gateway:** In the Azure Portal, go to your APIM instance -> APIs -> All APIs -> Design -> "Inbound Processing" -> Click `</>`.
4.  **Paste & Save:** Replace the default policy with your copied code.

## 📚 Included Resources (Links)
**Master the pattern with these expert deep-dives:**

### 🎥 Videos
- [**John Savill: Azure APIM Deep Dive**](https://www.youtube.com/watch?v=PXtFq5wmGt0) - Essential theory.
- [**Microsoft Mechanics: Secure GenAI**](https://www.youtube.com/watch?v=6Mmevs1877A) - Focus on Content Safety.

### 💻 GitHub Repos (Source Code)
- [**Smart Load Balancing**](https://github.com/Azure/apim-aoai-smart-loadbalancing) - Handle failover & quotas.
- [**Enterprise Token Logging**](https://github.com/Azure-Samples/openai-python-enterprise-logging) - Chargeback implementation.

### 📝 Official Guides
- [**Protect OpenAI with APIM**](https://techcommunity.microsoft.com/t5/fasttrack-for-azure/protect-azure-openai-with-azure-api-management/ba-p/3847936) - The auth pattern.

### 🎨 Official Visio Stencils
- [**Download Azure Architecture Stencils**](https://arch-center.azureedge.net/US-1004169/azure-architecture-center-stencils.vssx) - Use these to edit the diagrams.

## ⚠️ Requirements
- Azure API Management (Standard or Premium recommended for VNET).
- Azure OpenAI Service (Two deployments: Public & Private).

Happy Building!
- *Upendra Kumar*
