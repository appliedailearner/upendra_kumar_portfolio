# Retrieval Filter Patterns (Security Trimming)

## Rule: identity claims are trusted. User inputs are not.

### Pattern A: Group-based trimming
Filter: `allowedGroups IN user.groups`

### Pattern B: Department + classification
Filter: `dept == user.dept AND classification <= user.clearance`

### Pattern C: Document ACL mapping table
Filter: `docId IN allowedDocIdsForUser(userId)`

## Must-have validations
- deny if no identity claims
- deny if filter is empty and user is not privileged
- log filters applied for audit
