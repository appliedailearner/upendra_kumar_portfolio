# Runbook: Model Deployment Swap

## Trigger
Model deployment misbehaves (latency, errors, quality regressions).

## Detect
- p95 latency spike
- quality regressions in golden test set
- refusal rate abnormal

## Immediate actions
1. Route traffic to previous model deployment
2. Lower temperature / max tokens
3. Enable strict validator mode

## Escalation
- AI owner (deployment)
- App owner (orchestrator)

## Rollback
- revert modelDeploymentId in config
