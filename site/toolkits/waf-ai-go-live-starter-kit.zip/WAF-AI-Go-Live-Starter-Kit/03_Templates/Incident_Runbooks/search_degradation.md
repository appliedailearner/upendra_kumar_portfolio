# Runbook: Search Degradation

## Trigger
Search latency increases or retrieval relevance drops.

## Detect
- Search latency p95 breached
- no-results rate increasing
- citation coverage drops

## Immediate actions
1. Reduce topK
2. Switch to keyword-only fallback briefly
3. Rebuild index if freshness is stale
4. Check filters are not over-restrictive

## Escalation
- Data owner (index)
- Security owner (filters)

## Rollback
- Roll back index version
