# Runbook: Ingestion Backlog

## Trigger
Queue depth steadily increasing, processing lag > SLA.

## Detect
- Queue depth rising
- avg processing time increasing
- poison messages increasing

## Immediate actions
1. Scale ingestion workers
2. Pause low-priority ingestion jobs
3. Validate Document Intelligence throughput limits
4. Route large docs to async processing

## Escalation
- Data owner (pipeline)
- Platform owner (runtime scaling)

## Rollback
- Revert recent chunking/indexing changes
