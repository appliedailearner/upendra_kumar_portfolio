# Runbook: Model 429 Throttling

## Trigger
Spike in 429 errors from model endpoint or gateway.

## Detect
- 429 rate > threshold
- p95 latency increasing
- token/request increasing

## Immediate actions
1. Reduce max tokens per request (APIM policy)
2. Increase rate limiting for external product
3. Enable caching for frequent prompts (if applicable)
4. Fail gracefully with retry-after messaging

## Escalation
- Platform owner (APIM)
- AI owner (model quota / deployment)

## Rollback
- Restore previous APIM policy version
