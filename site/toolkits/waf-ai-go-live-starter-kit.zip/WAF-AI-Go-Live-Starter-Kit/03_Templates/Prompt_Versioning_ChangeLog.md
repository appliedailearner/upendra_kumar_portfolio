# Prompt + Retrieval Change Log

Use this file to track behavior changes safely.

## Template
- Date:
- Change type: Prompt / Retrieval / Index / Policy / Model
- Version:
- Summary:
- Why:
- Risk:
- Tests run:
- Rollback plan:
- Approved by:
