# APIM Policy Checklist (Wave 1)

## Boundary rules
- Validate JWT (audience, issuer, expiry)
- Enforce rate limits per subscription/product
- Enforce token budgets (max tokens/request)
- Block direct access to OpenAI/Search from clients
- Add correlation ID headers (`requestId`)

## Safety controls
- Content safety check route (optional) for input/output
- Block known injection patterns (basic)
- Restrict tool execution routes to allow-listed APIs

## Observability
- Log requestId, userId, productId, route, latency, status, token usage
- Emit structured logs for audit and investigations
