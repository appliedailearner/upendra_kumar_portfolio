# WAF AI Summary (Wave 1)

This kit is built around a simple idea:

**A Copilot is production-ready only when it is safe, reliable, cost-controlled, testable, and operable.**

## Non-negotiables (Wave 1)
1. **APIM-first boundary**: clients call APIM only
2. **Two lanes**: Chat vs Ingestion are isolated (bulkheads)
3. **Citations required**: evidence-or-refusal enforced server-side
4. **Token budgets**: stop runaway costs at the gateway
5. **Permission-aware retrieval**: retrieval filters enforce authorization

## What “done” means
- Answers always cite sources or refuse
- Every response is traceable by `requestId`
- Cross-team leakage is prevented by security trimming
- p95 latency is within target at expected load
- Operators have runbooks and dashboards
