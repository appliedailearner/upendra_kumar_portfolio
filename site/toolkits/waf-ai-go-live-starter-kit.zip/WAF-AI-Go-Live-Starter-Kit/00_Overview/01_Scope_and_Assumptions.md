# Scope and Assumptions (Wave 1)

Use this page to align stakeholders before build.

## In scope
- RAG-based Copilot on enterprise documents
- Private API gateway boundary (APIM)
- Ingestion pipeline (extract → chunk → embed → index)
- Audit trail, citations, and access control
- Day-2 operations (dashboards + runbooks)

## Out of scope (Wave 1)
- Fine-tuning large foundation models
- Custom UI build from scratch (assume Teams/WebUI)
- Complex multi-tenant B2C identity integrations
- Advanced agent tools and workflows beyond “read + answer + cite”

## Key decisions to lock early
- Index strategy (1 index vs many, versioning)
- Access model (RBAC claims, groups, document ACL)
- Token and rate limits (per product/route)
- Go/no-go gates and golden test set ownership
