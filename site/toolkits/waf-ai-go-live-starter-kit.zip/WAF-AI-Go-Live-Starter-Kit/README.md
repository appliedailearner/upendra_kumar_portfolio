# WAF AI Go-Live Starter Kit (Wave 1)

A practical, client-ready kit to plan, build, review, and launch **production-grade AI copilots on Azure** using the **Azure Well-Architected Framework (AI workload guidance)**.

## What this kit helps you do
- Design a **two-lane architecture** (Chat + Ingestion) with one **APIM boundary**
- Enforce **evidence-or-refusal**, **audit trail**, and **permission-aware retrieval**
- Set **go/no-go gates** and run **golden test sets**
- Operate the workload with **Day-2 runbooks** and measurable signals
- Align stakeholders with a clear **RACI and operating model**

## How to use (fast path)
1. Read **00_Overview/00_WAF_AI_Summary.md**
2. Use **02_Checklists/** for design + review workshops
3. Populate **03_Templates/** (scorecard, risks, test set, runbooks)
4. Attach the diagrams in **01_Architecture/** into your deck or design doc
5. Run the **WAF AI Assessment** and track gaps as backlog items

## Contents
- `01_Architecture/` reference diagrams + hero video
- `02_Checklists/` WAF-based checklists by topic
- `03_Templates/` ready-to-fill templates + runbooks
- `04_Working_Examples/` sample request/response/audit payloads
- `05_Blog/` the Part-3 playbook markdown

## Source references (Microsoft Learn)
- https://learn.microsoft.com/en-us/azure/well-architected/ai/design-principles
- https://learn.microsoft.com/en-us/azure/well-architected/ai/application-design
- https://learn.microsoft.com/en-us/azure/well-architected/ai/application-platform
- https://learn.microsoft.com/en-us/azure/well-architected/ai/training-data-design
- https://learn.microsoft.com/en-us/azure/well-architected/ai/grounding-data-design
- https://learn.microsoft.com/en-us/azure/well-architected/ai/data-platform
- https://learn.microsoft.com/en-us/azure/well-architected/ai/mlops-genaiops
- https://learn.microsoft.com/en-us/azure/well-architected/ai/operations
- https://learn.microsoft.com/en-us/azure/well-architected/ai/test
- https://learn.microsoft.com/en-us/azure/well-architected/ai/responsible-ai
- https://learn.microsoft.com/en-us/azure/well-architected/ai/personas
- https://learn.microsoft.com/en-us/azure/well-architected/ai/assessment

## License
Use freely in client work. Attribution appreciated.
