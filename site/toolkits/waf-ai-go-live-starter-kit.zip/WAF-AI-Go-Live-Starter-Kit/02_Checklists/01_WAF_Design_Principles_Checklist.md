# WAF Design Principles Checklist

## Goal
Translate WAF pillars into concrete controls for AI workloads.

## Checklist
- [ ] Reliability: bulkheads exist (Chat vs Ingestion)
- [ ] Reliability: retry/backoff + circuit breaker for model/search calls
- [ ] Security: APIM is the only ingress path
- [ ] Security: no direct UI access to OpenAI/Search data planes
- [ ] Cost: token budget per route (chat vs ingestion) enforced
- [ ] Cost: rate limiting per product (internal vs external)
- [ ] Ops: trace IDs exist end-to-end (`requestId`)
- [ ] Performance: p95 latency targets set and measurable
