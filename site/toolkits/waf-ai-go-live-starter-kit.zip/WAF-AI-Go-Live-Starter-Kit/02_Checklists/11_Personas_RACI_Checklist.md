# Personas and RACI Checklist

## Goal
Avoid “who owns what?” confusion during incidents.

## Checklist
- [ ] Product owner defined for business outcomes and acceptance gates
- [ ] App owner defined for orchestrator behavior and validators
- [ ] Data owner defined for ingestion, chunking, and index quality
- [ ] Platform owner defined for APIM/networking/IaC
- [ ] Security owner defined for policy and content safety thresholds
- [ ] SRE/ops owner defined for alerts and runbooks
