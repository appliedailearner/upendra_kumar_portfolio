# WAF Assessment Cadence

## When to run
- Design time (before build)
- Pre-prod (before go-live)
- Every 4 months (or after major changes)

## What to do with results
- Export gaps to CSV
- Convert to backlog work items
- Track owners and due dates
- Re-run after remediation
