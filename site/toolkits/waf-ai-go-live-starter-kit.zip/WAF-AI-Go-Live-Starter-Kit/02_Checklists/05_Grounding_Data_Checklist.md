# Grounding Data Design Checklist (RAG)

## Goal
Maximize citation quality and relevance while controlling latency and cost.

## Checklist
- [ ] Chunking strategy defined (page-aware + semantic boundaries)
- [ ] Chunk metadata includes docId, page, ACL tags, indexVersion
- [ ] Retrieval uses hybrid search (keyword + vector)
- [ ] Security trimming enforced server-side
- [ ] topK limits set (3–8)
- [ ] Citation validator rejects invalid chunks
