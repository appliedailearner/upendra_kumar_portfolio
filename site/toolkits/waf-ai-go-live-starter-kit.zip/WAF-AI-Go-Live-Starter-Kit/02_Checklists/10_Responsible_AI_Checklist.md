# Responsible AI Checklist

## Goal
Enforce responsible AI policies in engineering, not slide decks.

## Checklist
- [ ] Content safety checks for inputs + outputs
- [ ] User data transparency and consent approach documented
- [ ] Right-to-be-forgotten (RTBF) process defined
- [ ] PII policy (refuse/redact) enforced
- [ ] Human escalation path exists
- [ ] Governance cadence defined (monthly/quarterly reviews)
