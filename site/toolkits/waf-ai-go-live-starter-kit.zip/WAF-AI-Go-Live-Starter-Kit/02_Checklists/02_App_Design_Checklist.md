# Application Design Checklist (AI Workloads)

## Goal
Build an AI workload that can adapt to non-determinism and avoid “demo-only” behavior.

## Checklist
- [ ] Orchestrator owns business rules (not the UI)
- [ ] Evidence-or-refusal enforced by validator (server-side)
- [ ] Prompt injection protections exist (input + document-based)
- [ ] Model routing and fallback behaviors defined
- [ ] Versioning exists for prompts + index + policies + model deployments
- [ ] Feedback loop exists (thumbs down, missing citation, wrong doc)
