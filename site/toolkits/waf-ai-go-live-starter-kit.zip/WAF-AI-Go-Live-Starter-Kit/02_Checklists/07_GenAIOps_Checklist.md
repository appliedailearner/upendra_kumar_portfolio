# GenAIOps Checklist

## Goal
Operate prompts + retrieval + safety like a real software lifecycle.

## Checklist
- [ ] Prompt versioning and approvals
- [ ] Golden test set run per release
- [ ] Safety evaluation gates included
- [ ] Rollback plan for prompt/model/index
- [ ] Release notes include changes to behavior
