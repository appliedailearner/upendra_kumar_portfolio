# Application Platform Checklist

## Goal
Choose the right runtime for each function (ingestion, orchestration, APIs).

## Checklist
- [ ] AKS vs ACA decision documented (why)
- [ ] Separate scaling for ingestion vs chat services
- [ ] Private networking approach defined (PE, DNS, routing)
- [ ] Secrets stored in Key Vault, not config files
- [ ] CI/CD to deploy app + infra consistently
