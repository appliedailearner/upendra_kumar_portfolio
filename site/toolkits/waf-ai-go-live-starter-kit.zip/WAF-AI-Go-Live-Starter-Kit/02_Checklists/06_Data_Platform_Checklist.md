# Data Platform Checklist

## Goal
Keep the platform simple unless complexity is required.

## Checklist
- [ ] ADLS structure defined (`landing/`, `processed/`, `audit/`)
- [ ] Lifecycle management (retention/archival) defined
- [ ] Index rebuild strategy and versioning defined
- [ ] Auditability: source-to-answer trace exists
