# Testing Checklist

## Goal
Prove the system behaves correctly under failure and adversarial inputs.

## Checklist
- [ ] Golden test set exists (30–50 questions)
- [ ] Must-refuse tests included
- [ ] Prompt injection tests included
- [ ] Failure simulation: 429 throttling and timeouts
- [ ] Citation coverage gating exists
- [ ] Cost-aware load testing plan exists
