# Operations Checklist (Day 2)

## Goal
Run the system daily without heroics.

## Checklist
- [ ] Dashboards: p95 latency, refusal rate, 429 rate, queue depth, token/request
- [ ] Alerts: throttling spikes, index freshness breach, poison messages
- [ ] Runbooks exist for top incidents (429, backlog, search degradation)
- [ ] Ownership model published (RACI)
