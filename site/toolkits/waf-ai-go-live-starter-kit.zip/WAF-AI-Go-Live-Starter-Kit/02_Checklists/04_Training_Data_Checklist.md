# Training Data Design Checklist

## Goal
Prepare data for evaluation or future tuning without leaking sensitive information.

## Checklist
- [ ] Data segmentation aligned to security boundaries
- [ ] Preprocessing defined (dedupe, normalize, remove noise)
- [ ] Drift signals defined (data drift + concept drift)
- [ ] Privacy and sensitive data handling defined (minimize, anonymize)
