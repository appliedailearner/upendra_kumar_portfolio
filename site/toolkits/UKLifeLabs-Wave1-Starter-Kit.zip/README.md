# Wave 1 Starter Kit: Document Intelligence Copilot

This toolkit provides the implementation artifacts for the blog series:
- **Part 1:** [Architecture Blueprint](https://portfolio.upendrakumar.com/blog/2026-01-17-document-intelligence-copilot-azure.html)
- **Part 2:** [Implementation Guide](https://portfolio.upendrakumar.com/blog/2026-01-18-document-intelligence-implementation-guide.html)

## Included Artifacts

### 1. API Management Policies (`/policies`)
- `apim-policy-validate-jwt.xml`: Enforces JWT validation and token limits.
- `apim-policy-log-to-eventhub.xml`: Captures the robust Audit Log schema required for compliance.

### 2. Data Schemas (`/schemas`)
- `ai-search-index.json`: The Azure AI Search index definition supporting `group_ids` security trimming.
- `citation-response.json`: The JSON contract your UI must handle for valid citations.
- `audit-log-event.json`: The schema of the events sent to Event Hub.

### 3. Load Testing (`/tests`)
- `locustfile.py`: A Python Locust script to simulate 100 concurrent chat users.

## How to Use
1. **APIM:** Import the XML fragments into your API Policy editor (inbound section).
2. **AI Search:** Use the JSON payload in the "Import Data" wizard or REST API.
3. **Tests:** Run `locust -f locustfile.py --host https://your-api-gateway.com`

---
*Created by [Upendra Kumar](https://portfolio.upendrakumar.com)*
