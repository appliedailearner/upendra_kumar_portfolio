from locust import HttpUser, task, between
import json

class ChatUser(HttpUser):
    wait_time = between(1, 3)

    @task
    def chat_query(self):
        headers = {
            "Authorization": "Bearer YOUR_TEST_TOKEN",
            "Content-Type": "application/json"
        }
        payload = {
            "messages": [
                {"role": "user", "content": "What is the policy on remote work?"}
            ]
        }
        
        with self.client.post("/v1/chat/completions", json=payload, headers=headers, catch_response=True) as response:
            if response.status_code == 200:
                response.success()
            elif response.status_code == 429:
                response.failure("Rate Limit Exceeded (Expected behavior if over quota)")
            else:
                response.failure(f"Failed with status {response.status_code}")
