# Wave 1 Starter Kit (UKLifeLabs)

Purpose: give a first-time Azure migration team a practical, repeatable set of templates for Wave 1.

## What to do first (30 minutes)
1. Open **01_Discovery/Server_Inventory_Template.xlsx** and list servers in scope.
2. Open **01_Discovery/Application_Inventory_Template.xlsx** and map apps to those servers.
3. Open **06_Wave_Planning/Wave_Plan_Template.xlsx** and define Wave 1 = 30 app services.
4. Use **02_Azure_Migrate/Assessment_Run_Tracker.xlsx** to track Azure Migrate discovery and assessment runs.
5. Use **04_Finance/TCO_Assumptions.xlsx** to lock assumptions before you show numbers.

## Outputs you should have by end of Wave 1 planning
- Server + application inventory (clean)
- Dependency capture for Wave 1
- Azure Migrate assessments (or a clear exception list)
- TCO summary + business case bullets
- Funding + PoE evidence pack outline (if applicable)
