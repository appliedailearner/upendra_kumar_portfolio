# Glossary

- **TCO (Total Cost of Ownership):** all costs to run workloads for a period (usually 3 to 5 years). Not just VM price.
- **Business Case:** executive narrative to decide ‘why now’. Uses TCO plus risk, speed, compliance, and growth outcomes.
- **PoE (Proof of Execution):** evidence that funded activities were actually performed and outcomes delivered.
- **Wave:** a batch of apps/servers migrated together.
- **Landing Zone:** the secured Azure foundation (identity, network, governance, monitoring).
