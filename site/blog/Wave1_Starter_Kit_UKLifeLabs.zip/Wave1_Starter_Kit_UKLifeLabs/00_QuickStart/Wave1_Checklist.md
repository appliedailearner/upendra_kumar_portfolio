# Wave 1 Checklist (print this)

## Scope lock
- [ ] Wave 1 apps selected (30 app services)
- [ ] Owners confirmed for each app
- [ ] Target regions and landing zone decision recorded

## Discovery and assessment
- [ ] Azure Migrate appliance deployed
- [ ] Discovery complete for servers in scope
- [ ] Assessments created (performance-based) for Wave 1 servers
- [ ] Exceptions list documented (servers not discovered, blocked, or missing performance)

## Dependencies and network
- [ ] Top inbound and outbound flows captured for each Wave 1 server
- [ ] Ports categorized (SQL, AD/LDAP, Web, SMB, etc.)
- [ ] Network rule request prepared and reviewed

## Finance
- [ ] TCO assumptions agreed (term, discounts, licensing, backup, monitoring)
- [ ] TCO summary produced for Wave 1 and for whole scope
- [ ] Business case bullets drafted (risk, speed, compliance)

## Execution readiness
- [ ] Cutover runbook drafted
- [ ] Validation test plan drafted
- [ ] Change record and signoff templates ready
