# Azure Migrate appliance deployment checklist

- [ ] Correct subscription + permissions confirmed
- [ ] Network access confirmed (proxy, firewall, outbound URLs)
- [ ] Appliance deployed (VMware/Hyper-V/physical supported)
- [ ] Discovery source connected and validated
- [ ] Discovery runs scheduled and monitored
- [ ] Export discovery inventory snapshot saved
