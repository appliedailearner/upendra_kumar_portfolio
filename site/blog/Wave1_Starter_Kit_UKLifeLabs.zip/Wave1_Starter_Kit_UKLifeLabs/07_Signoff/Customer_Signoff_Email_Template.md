Subject: Wave 1 readiness signoff required (UKLifeLabs)

Hi Team,

We are ready to lock Wave 1 (30 app services) for the Azure migration plan.

Please reply with approval (or comments) on the following:
1) Wave 1 scope list (apps + servers)
2) Dependency and network rule requirements
3) Migration window preferences and change governance

If approved, we will proceed to finalize the runbooks and schedule the pilot cutover.

Thanks,
