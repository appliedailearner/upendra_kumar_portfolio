# Port lookup troubleshooting (Excel)

If your formula gives **"There's a problem with this formula"**, check these first:

1) **Is your data an Excel Table?**
   - Structured references like `[@[Destination Port]]` only work inside a table column.
   - Fix: expand the table to include your new column (e.g., "Port Category").

2) **Comma vs semicolon separators**
   - Some regions use `;` instead of `,` in formulas.
   - If Excel rejects your formula, try swapping separators.

3) **XLOOKUP support**
   - If your Excel version is older, use `VLOOKUP` instead.

Example (table column formula):
- With semicolons:
  `=IFERROR(VLOOKUP([@Port];PortTable[[Port]:[Category]];2;FALSE);"Other")`

Tip: name your mapping table **PortTable** and keep columns **Port** and **Category**.
