# Sample PoE Pack Index (example)

> This is a suggested evidence structure. Exact requirements vary by program, region, and offer.

## A. Customer and scope
- Signed scope / email confirmation
- Wave plan (Wave 1 list)

## B. Work performed
- Azure Migrate discovery exports
- Assessment exports and settings (screenshots)
- Dependency capture sheet for Wave 1

## C. Outcomes delivered
- Business case summary (TCO + key outcomes)
- Landing zone readiness checklist

## D. Execution proof
- Change records / runbooks
- Cutover evidence (screenshots, logs)
- Validation signoff

## E. Financial proof (if requested)
- Funding request ID and approvals
- Consumption or invoice evidence (if applicable)
