# Validation Test Plan Template

## Scope
- App/service:
- Owner:

## Tests
| Test | Expected Result | Owner | Status |
|---|---|---|---|
| Login | Successful | | |
| Core workflow | Works end-to-end | | |
| Integration | Downstream calls succeed | | |

## Evidence
- Screenshots / logs location:
