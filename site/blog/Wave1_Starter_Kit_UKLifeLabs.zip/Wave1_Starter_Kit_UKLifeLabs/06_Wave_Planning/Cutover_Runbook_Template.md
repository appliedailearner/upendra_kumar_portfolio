# Cutover Runbook Template

## 1. Change details
- Change ID:
- Planned window:
- Systems impacted:
- Rollback owner:

## 2. Pre-cutover
- Freeze window start:
- Backups taken and verified:
- Final replication health check:

## 3. Cutover steps
1. Notify stakeholders
2. Stop application services (list)
3. Final sync / replication
4. Bring up target systems
5. Update DNS / load balancer routes

## 4. Validation
- Smoke tests:
- Functional tests:
- Performance checks:

## 5. Rollback plan
- Trigger criteria:
- Steps:
