# SLOs and Metrics

## Suggested SLOs
- Chat availability: 99.9%
- Index freshness: 15 min target, 30 min max

## What to monitor (per APIM Product)
- p50/p95 latency
- 429 rate
- TPM usage per hour
- Top consumers

## Retrieval quality signals
- Evidence hit rate (chunks returned)
- Citation coverage ratio
- Answer fallback rate ("Not enough evidence")
