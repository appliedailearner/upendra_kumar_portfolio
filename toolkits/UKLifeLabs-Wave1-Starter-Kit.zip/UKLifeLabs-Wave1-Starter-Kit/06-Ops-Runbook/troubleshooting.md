# Troubleshooting

## Problem: 429 throttling
Likely causes:
- deployment TPM/RPM too low
- no lane separation (ingestion competes with chat)

Fix:
- throttle bulk ingestion
- raise quota or add PTU for chat
- tighten APIM limits for external users

## Problem: Answers without citations
Likely causes:
- prompt not enforcing citation requirement
- retrieval returning empty results

Fix:
- enforce "No citations, no final answer"
- tune chunking and Search query settings

## Problem: Data leakage across departments
Likely causes:
- permission trimming not applied

Fix:
- always filter by allowedGroups/department/classification
- log trimming filter input for audit
