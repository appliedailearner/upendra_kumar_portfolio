# Go-Live Checklist

## Security
- [ ] UI calls APIM only
- [ ] JWT validation enabled on internal and external routes
- [ ] Permission trimming enforced in AI Search queries

## Cost control
- [ ] Rate limits set per APIM Product
- [ ] Token budgets configured (TPM/min + daily caps)
- [ ] Prompt + response caps enforced

## Quality
- [ ] Citations required for every response
- [ ] If evidence is missing, return "Not enough evidence"

## Freshness
- [ ] Two ingestion queues live (high vs bulk)
- [ ] Bulk queue throttled to protect chat

## Audit
- [ ] Audit records store user, chunkIds, indexVersion, modelDeploymentId
