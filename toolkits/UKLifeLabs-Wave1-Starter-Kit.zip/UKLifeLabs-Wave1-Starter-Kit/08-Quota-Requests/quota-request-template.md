# Quota / PTU Request Template

## Context
- Employees: 6,500
- Target users Year 1: 700
- Peak traffic: 140 RPM
- Avg tokens/request: ~3,000

## Deployment quota ask (starting point)
- Interactive Chat: 550k TPM
- Embeddings: 300k TPM
- Batch summaries: 250k TPM
- Total: ~1.1M TPM

## PTU recommendation
Use PTU for **Interactive Chat** if it is mission-critical:
- predictable latency
- reduced throttling during peak

## Notes
- Keep ingestion queue-driven
- Throttle bulk ingestion to protect chat
- Enforce token budgets at APIM
