# Managed Identity Setup (No Secrets)

## Goal
APIM and backend services should authenticate to Azure services using Managed Identity.

## Minimum tasks
- Enable Managed Identity on APIM
- Grant APIM MI access to Azure OpenAI / Foundry
- Grant workload MI access to AI Search (query) and Storage (read)

## Why this matters
- No secrets in config files
- Better audit trail
- Easier rotation and governance
