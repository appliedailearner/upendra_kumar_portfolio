# Private Endpoints Checklist

## Services to consider private endpoints for
- Storage (ADLS Gen2)
- Azure AI Search
- Azure OpenAI / Foundry (if supported in region)
- PostgreSQL Flexible Server

## DNS requirements
- Private DNS zones created and linked to VNets
- DNS forwarders in hub if required
- Validate name resolution from workload subnet

## Validation tests
- From AKS/worker subnet: resolve service FQDN to private IP
- Block public network access (where supported)
- Ensure APIM can reach backends privately
