# Key Vault Secret Hygiene

## What belongs in Key Vault
- DB passwords (PostgreSQL)
- API keys (only if unavoidable)
- TLS certs

## What should NOT be in plain config
- Connection strings
- Shared keys

## Operational baseline
- Access via Managed Identity
- Rotate secrets on a schedule
- Log secret access events
