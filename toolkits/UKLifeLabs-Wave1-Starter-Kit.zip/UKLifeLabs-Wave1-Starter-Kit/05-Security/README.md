# Security Pack (Wave 1)

Focus areas:
- Private endpoints + Private DNS
- Managed Identity to reach Foundry/OpenAI
- Key Vault secret hygiene

Files:
- `private-endpoints-checklist.md`
- `managed-identity-setup.md`
- `keyvault-secrets.md`
