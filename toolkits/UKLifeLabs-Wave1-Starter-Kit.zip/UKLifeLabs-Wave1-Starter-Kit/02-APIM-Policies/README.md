# APIM Policy Pack (Wave 1)

These snippets are designed to be attached at:
- **Product level** (internal vs external)
- **API level** (shared policies)
- **Operation level** (specific endpoints like /chat)

## Recommended policy layering
- **All APIs**: correlation + logging
- **Internal Product**: higher rate limits, larger caps
- **External Product**: strict rate limits, smaller caps

Files:
- `validate-jwt-internal.xml`
- `validate-jwt-external.xml`
- `rate-limit-internal.xml`
- `rate-limit-external.xml`
- `token-budget-guard.xml`
- `request-guardrails.xml`
- `correlation-logging.xml`

Note: token budget enforcement depends on your model integration. Use APIM LLM/token policies where supported.
