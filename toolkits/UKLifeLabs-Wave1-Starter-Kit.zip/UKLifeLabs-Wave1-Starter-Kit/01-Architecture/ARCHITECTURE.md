# Architecture Blueprint (Wave 1)

## Goal
Employees upload document packs, extract key fields, and ask questions with **citations + audit trail**.

## Non-negotiables
1) **APIM-first boundary**: UI must call APIM only
2) **Two lanes**: Chat vs Ingestion
3) **Citations required**: No proof, no answer
4) **Token budgets at gateway**: stop runaway costs
5) **Permission-aware retrieval**: prevent data leakage across teams

## Simple runtime topology
- **UI** (Teams / Web Portal / Open WebUI)
- **APIM (private)** as AI Gateway
- **Workloads** (AKS recommended for production)
- **ADLS** for raw docs + extracted JSON + audit artifacts
- **Document Intelligence** for extraction
- **Azure AI Search** for retrieval + vectors
- **Azure OpenAI / Foundry** for model inference

## Flow A: Chat request
1) UI -> APIM `/v1/private/chat`
2) APIM validates JWT, rate limits, token budgets
3) Copilot API queries AI Search (with permission filters)
4) Copilot API calls model with retrieved chunks
5) Response returns with citations
6) Audit trail saved (user, chunkIds, indexVersion, modelDeploymentId)

## Flow B: Ingestion
1) PDF lands in ADLS `landing/`
2) Event triggers ingestion worker
3) Document Intelligence extracts text/fields
4) Chunk + embed
5) Index to AI Search
6) Store extraction JSON + chunk map + trace in ADLS `audit/`

## AKS vs ACA (Wave 1 decision)
- **AKS**: best for regulated production patterns (ingress control, isolation, multiple internal services)
- **ACA**: good for rapid pilot, fewer ops, but less control for complex enterprise segmentation

## Internal vs External
Start with **one APIM instance** + **two Products**:
- Product A: Internal Employees
- Product B: External Partners

External must never starve internal.
