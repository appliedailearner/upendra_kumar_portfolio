# UKLifeLabs Wave 1 Starter Kit (Document Intelligence + Copilot)

This kit is designed to help you implement **Wave 1** of the architecture described in the blog:
- **APIM-first** AI Gateway boundary
- **Private-first networking**
- **RAG with citations** ("No proof, no answer")
- **Two lanes** (Chat vs Ingestion)
- **Internal vs External** isolation using APIM Products

## What’s inside
1. **01-Architecture**: reference architecture + flows
2. **02-APIM-Policies**: policy snippets for JWT, throttling, token budgets, guardrails
3. **03-RAG**: AI Search index schema + permission trimming patterns
4. **04-Ingestion**: queue pattern (high vs bulk) + runbook
5. **05-Security**: private endpoints + Managed Identity + Key Vault patterns
6. **06-Ops-Runbook**: go-live checklist + metrics + troubleshooting
7. **07-Test-Cases**: test plan to validate controls
8. **08-Quota-Requests**: quota/PTU request templates

## Wave 1 success criteria
- UI calls **APIM only**
- APIM enforces **JWT + rate limits + token budgets**
- Answers return with **citations**
- Ingestion meets **15-min freshness** for new docs
- Security trimming is enforced (no cross-team data leakage)

Open **01-Architecture/ARCHITECTURE.md** first.
