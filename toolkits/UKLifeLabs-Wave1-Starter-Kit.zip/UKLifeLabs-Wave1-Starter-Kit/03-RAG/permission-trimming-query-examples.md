# Permission Trimming (Security-Aware Retrieval)

## Goal
A user must never retrieve chunks they are not allowed to see.

## Required metadata
Every chunk must carry:
- allowedGroups[] (Entra group IDs or stable group codes)
- department
- classification

## Retrieval rule (must enforce)
When querying AI Search, include a filter like:

### Example filter (group based)
```
allowedGroups/any(g: g eq '<GROUP_ID_1>' or g eq '<GROUP_ID_2>')
```

### Example filter (group + classification)
```
allowedGroups/any(g: g eq '<GROUP_ID>') and classification ne 'Restricted'
```

## What to log for audit
Store in your audit record:
- user oid/tid
- group list used for trimming
- returned chunkIds
- indexVersion

If you cannot prove the filter was applied, you cannot pass audit.
