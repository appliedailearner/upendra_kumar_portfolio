# RAG Templates (Azure AI Search)

This folder provides a **starter index schema** and guidance for **permission-aware retrieval**.

Core idea:
- Store the document content in chunks
- Store metadata for security trimming (allowedGroups, department, classification)
- Always filter search results by user context

Files:
- `search-index-schema.json`
- `permission-trimming-query-examples.md`
- `chunking-guidelines.md`
