# Chunking Guidelines (Practical)

## Baseline
- Chunk size: 800–1200 tokens
- Overlap: 100–200 tokens
- Preserve headers and section titles as metadata

## Why this matters
- Too small = low context, weak answers
- Too large = high cost, slow answers

## Always include in citation payload
- docId
- pageNumber
- sectionTitle (if available)
- sourceUri
