# Wave 1 Test Plan

## Identity tests
- Invalid JWT returns 401
- Valid JWT but missing required claims returns 403

## Throttling tests
- Internal product supports expected RPM
- External product hits 429 at configured rate

## Token budget tests
- Large prompt is rejected or clamped
- Daily caps block excessive use

## Retrieval tests (permission trimming)
- User A cannot retrieve User B department docs
- Allowed group docs are returned with citations

## Freshness tests
- New doc ingested and searchable within 15 minutes
- Bulk ingestion does not increase chat 429 rate above threshold
