# Two-Queue Pattern

## Queues
1) `intake-high` (new docs, SLA)
2) `intake-bulk` (backlog)

## Scheduling rules
- Always drain `intake-high` first
- Throttle `intake-bulk` (night/weekends)

## Why this matters
Backlog ingestion is a long-running workload. If you let it compete with chat, you will:
- miss freshness targets
- degrade chat latency
- trigger model throttling (429)
