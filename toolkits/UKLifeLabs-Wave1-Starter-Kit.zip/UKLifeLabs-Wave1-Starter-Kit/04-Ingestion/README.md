# Ingestion Runbook (Wave 1)

Your ingestion pipeline must meet:
- 8,000 docs/day
- 15-minute freshness for new docs
- backlog ingestion without breaking chat

Core pattern:
- Two queues: `intake-high` and `intake-bulk`
- `intake-high` always wins scheduling priority

Files:
- `ingestion-queues.md`
- `pipeline-runbook.md`
- `bulk-throttle-config.yaml`
