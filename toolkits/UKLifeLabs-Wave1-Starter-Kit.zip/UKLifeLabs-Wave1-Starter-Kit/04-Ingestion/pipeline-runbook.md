# Ingestion Pipeline Runbook

## Step-by-step
1) File lands in ADLS: `landing/`
2) Event triggers ingestion worker
3) Run Document Intelligence extraction
4) Normalize extracted text + fields
5) Chunk + enrich metadata
6) Create embeddings
7) Push to AI Search
8) Write audit artifacts to ADLS `audit/`

## What to store for audit
- docId
- sourceUri
- extractionModel/version
- chunkIds
- embeddingBatchId
- indexVersion
- ingestedAt

## Failure handling
- Extraction failed: retry with backoff, then quarantine file
- Index push failed: retry, do not drop
- If freshness SLO is breached: pause bulk queue, prioritize high queue
