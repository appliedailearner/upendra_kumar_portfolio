# UK South AI API Gateway (Palo Alto + FortiGate) Reference Architecture

## Goals
- Single enforced ingress path for **external** and **internal** consumers.
- Private-by-default backends.
- Clear control ownership: **Palo Alto (north-south)**, **FortiGate (east-west)**, **WAF + APIM (L7 governance)**.

## Logical flow
### External lane
Internet -> (optional) Cloudflare -> Palo Alto -> App Gateway (WAF) -> APIM -> Private backends (AKS/APIs/Azure OpenAI/Azure AI Search)

### Internal lane
Corp network -> VPN/ER -> Hub -> FortiGate (UDR forced) -> APIM -> Private backends

## Mermaid: high-level flow
```mermaid
flowchart LR
  U[Internet Users] --> CF[Cloudflare (optional)] --> PA[Palo Alto]
  PA --> WAF[App Gateway WAF]
  WAF --> APIM[API Management]
  APIM --> AKS[AKS / App APIs (Private)]
  APIM --> AOAI[Azure OpenAI / AI Foundry (Private)]
  APIM --> AIS[Azure AI Search (Private)]

  Corp[Corp Users] --> VPN[VPN/ExpressRoute] --> FG[FortiGate (UDR forced)] --> APIM
```

## Mermaid: APIM policy pipeline
```mermaid
sequenceDiagram
  participant C as Client
  participant W as AppGW WAF
  participant A as APIM
  participant B as Backend
  C->>W: HTTPS request
  W->>A: Forward (preserve X-Forwarded-For)
  A->>A: Inbound policies (auth, quotas, headers)
  A->>B: Backend call (private)
  B-->>A: Response
  A->>A: Outbound policies (headers, masking)
  A-->>W: Response
  W-->>C: Response
```
