# Threat Model Template (STRIDE)

## Scope
- External lane: Internet -> Palo Alto -> WAF -> APIM -> Backends
- Internal lane: Corp -> VPN/ER -> FortiGate -> APIM -> Backends

## Trust boundaries
- Internet boundary at Palo Alto.
- Internal segmentation boundary at FortiGate.
- L7 boundary at WAF and APIM.

## STRIDE table
| Threat | Example in this architecture | Primary control | Evidence to capture |
|---|---|---|---|
| Spoofing | Token theft, fake client | Entra ID + validate-jwt | APIM policy export, auth logs |
| Tampering | Request payload manipulation | TLS, WAF rules, schema validation | WAF policy, APIM policy |
| Repudiation | Caller denies actions | Correlation-id + central logs | Log query + sample trace |
| Information Disclosure | PII in logs or responses | Masking, log minimization | Logging config, sample scrub |
| Denial of Service | Burst calls, model throttling | WAF + APIM rate limits + quotas | Rate limit settings, load test |
| Elevation of Privilege | Over-broad scopes/roles | Least privilege + RBAC | RBAC review, MI usage |
