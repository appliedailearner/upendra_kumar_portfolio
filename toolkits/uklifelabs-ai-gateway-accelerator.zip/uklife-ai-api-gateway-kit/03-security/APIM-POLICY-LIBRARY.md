# APIM Policy Library (starter set)

## 1) Correlation ID (inbound)
```xml
<set-header name="x-correlation-id" exists-action="skip">
  <value>@(context.RequestId)</value>
</set-header>
```

## 2) Validate JWT (Microsoft Entra ID)
```xml
<validate-jwt header-name="Authorization" failed-validation-httpcode="401" failed-validation-error-message="Unauthorized">
  <openid-config url="https://login.microsoftonline.com/{tenant-id}/v2.0/.well-known/openid-configuration" />
  <audiences>
    <audience>{api-app-id-uri}</audience>
  </audiences>
  <required-claims>
    <claim name="iss" match="any">
      <value>https://sts.windows.net/{tenant-id}/</value>
    </claim>
  </required-claims>
</validate-jwt>
```

## 3) Rate limit by key (per subscription)
```xml
<rate-limit-by-key calls="60" renewal-period="60" counter-key="@(context.Subscription.Key)" />
```

## 4) Token budgeting pattern (AI endpoints)
- Track approximate token usage per request (header or inferred size)
- Apply rate limits tighter for external product

## 5) Block large bodies (avoid abuse)
```xml
<check-header name="Content-Length" failed-check-httpcode="413" failed-check-error-message="Payload too large">
  <value>@(context.Request.Headers.GetValueOrDefault("Content-Length","0"))</value>
  <operator>less-than</operator>
  <value>1048576</value>
</check-header>
```
