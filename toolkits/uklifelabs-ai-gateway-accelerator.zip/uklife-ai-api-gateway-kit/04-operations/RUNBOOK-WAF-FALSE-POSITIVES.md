# Runbook: WAF False Positives

## Symptoms
- Legit requests blocked (403) with WAF rule IDs.

## Triage
1. Confirm whether block is at Palo Alto or WAF.
2. For WAF, capture rule ID, matched variable, request path.
3. Determine if request is an API pattern (JSON, large payloads) triggering rules.

## Mitigation
- Start in detection mode for new apps, then tune.
- Add scoped exclusions by path + rule group when justified.
- Keep exclusions minimal. Document each with expiry and owner.
