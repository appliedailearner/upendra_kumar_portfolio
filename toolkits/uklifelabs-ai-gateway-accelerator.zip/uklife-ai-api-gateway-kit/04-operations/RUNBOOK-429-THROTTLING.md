# Runbook: 429 Throttling (AI and APIM)

## Symptoms
- Spikes of 429 from APIM or model endpoint.
- Increased latency and retries.

## Immediate actions (15 minutes)
1. Identify whether 429 is emitted by APIM policy or backend.
2. Check request volume by Product (Internal vs External).
3. Apply temporary tighter limits on External Product if needed.
4. If model quota is the bottleneck, reduce concurrency and batch requests.

## Root cause checklist
- Azure OpenAI quota insufficient in UK South.
- External clients not respecting retry-after.
- A single client key causing burst.

## Fix
- Implement client-side exponential backoff + retry-after.
- Separate deployments: chat vs embeddings vs batch.
- Move predictable workloads to provisioned capacity (PTU) where available.
