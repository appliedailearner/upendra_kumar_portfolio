# Build Order Checklist (UK South)

## 1) Network foundation
- Hub/spoke VNets created.
- Subnets: AppGW, APIM, AKS, Private Endpoints, FortiGate.
- VPN/ER connectivity established.
- Private DNS zones created + linked (APIM, OpenAI, Search, Storage as needed).

## 2) Palo Alto (north-south)
- Public VIPs only for required entrypoints.
- Allow-list and 443 only.
- Logging enabled to central sink.

## 3) FortiGate (east-west)
- UDRs applied on spoke subnets to force inter-VNet traffic through FortiGate.
- Confirm inspection in logs.

## 4) App Gateway WAF
- WAF enabled with managed rules.
- Listener + TLS certs.
- Backend pool points to APIM private endpoint / internal gateway.

## 5) APIM (private)
- APIM in internal mode (or private endpoint inbound, depending on tier/approach).
- Products: Internal, External.
- Policies: validate-jwt, rate-limit, correlation-id, request size limits.
- Diagnostics enabled.

## 6) Backends
- AKS private cluster and private ingress.
- Azure OpenAI / AI Foundry private connectivity.
- AI Search private endpoint.

## 7) Validation (Definition of Done)
- External path works and is logged across PA -> WAF -> APIM.
- Internal path works and is logged across FG -> APIM.
- No backend is publicly reachable.
- 429 behavior matches design and is recoverable.
