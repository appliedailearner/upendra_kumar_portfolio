# Visual Prompts (consistent style)

## 1) Reference architecture diagram
Prompt: "Create a clean Microsoft-style reference architecture diagram for Azure UK South: Internet -> (optional Cloudflare) -> Palo Alto -> Application Gateway WAF -> API Management -> private backends (AKS, Azure OpenAI via Private Link, Azure AI Search via Private Endpoint). Also show internal lane: Corp -> VPN/ER -> FortiGate -> APIM. Use clear trust boundaries and label north-south vs east-west." 

## 2) Threat model data flow diagram
Prompt: "Create a DFD with trust boundaries for the same architecture. Annotate where STRIDE threats apply and which control mitigates them." 

## 3) Routing and UDR flow
Prompt: "Create a network routing diagram showing spokes with UDRs forcing east-west traffic through FortiGate, and north-south ingress via Palo Alto." 

## 4) APIM policy pipeline
Prompt: "Create a simple 4-stage diagram: Inbound -> Backend -> Outbound -> On-error, with icons for validate-jwt, rate-limit, correlation-id, masking." 

## 5) Capacity planning visual
Prompt: "Create a one-page chart explaining TPM vs PTU and how to size tokens/min based on concurrency, avg tokens/request, and peak RPS." 
