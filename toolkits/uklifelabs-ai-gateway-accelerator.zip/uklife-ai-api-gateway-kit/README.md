# UK South AI API Gateway Kit

This kit supports the blog story and turns it into an implementable, auditable delivery pack.

## What's inside
- **01-architecture/**: reference architecture + Mermaid diagrams
- **02-sop/**: build order checklist + validation steps
- **03-security/**: threat model template + APIM policy library
- **04-operations/**: runbooks (429 throttling, WAF false positives)
- **05-governance/**: ADR template (model residency/capacity) + evidence pack checklist
- **06-visuals/**: prompts to generate consistent visuals
- **07-training/**: curated Microsoft Learn + Architecture Center + labs + videos
- **08-workshop/**: tabletop exercise to make the story interactive

## How to use
1. Put **ARCHITECTURE.md** in your design pack.
2. Use **BUILD-ORDER-CHECKLIST.md** during implementation.
3. Attach **EVIDENCE-PACK-CHECKLIST.md** for audit readiness.
4. Run the **TABLETOP-EXERCISE.md** with security, network, platform, app owners.
