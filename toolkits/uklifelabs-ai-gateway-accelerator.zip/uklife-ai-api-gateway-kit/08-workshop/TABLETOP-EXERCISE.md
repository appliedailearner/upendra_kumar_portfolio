# 60-Minute Tabletop Exercise (Interactive)

## Goal
Prove the design handles the top production failure modes: bypass, throttling, false positives, identity mistakes.

## Roles
- Security (owns accept/reject)
- Network (owns routing and firewalls)
- Platform (owns APIM/WAF)
- App team (owns retries, client behavior)

## Scenario A: Bypass attempt
- A partner tries to call backend directly.
- Expected: fails because backend has no public ingress.
- Evidence: backend exposure proof + deny logs.

## Scenario B: AI throttling storm
- A new feature causes 10x requests.
- Expected: APIM external product throttles, internal still works.
- Decision: temporary cap vs quota increase request.

## Scenario C: WAF blocks legitimate JSON
- Expected: identify WAF rule ID, apply scoped exclusion with owner + expiry.

## Output
- 1-page incident notes + actions + owners.
