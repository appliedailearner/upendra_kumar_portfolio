# Learning Path (curated)

## Microsoft Learn / Architecture Center
- Protect APIs using Application Gateway and API Management
- API Management in internal VNet mode
- API Management private endpoint (Private Link)
- Best practices for WAF on Application Gateway
- Azure OpenAI networking with private endpoints
- Mitigate OWASP API Security Top 10 with API Management
- Azure Well-Architected Framework + service guides for APIM and App Gateway

## Labs
- APIM policy snippets repository
- APIM Landing Zone Accelerator (secure baseline)
- APIM Lab (JWT validation exercises)

## Videos
- John Savill: Azure API Management Deep Dive
- Azure Essentials Show: Connecting OpenAI Private Endpoints Across VNets
