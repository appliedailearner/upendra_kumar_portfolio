# ADR: Model Residency and Capacity (UK South)

## Decision
- Requirement for UK-only inference: (Yes/No)
- Selected region(s): UK South (Primary), UK West (DR)
- Model(s):
- Deployment type: Standard (TPM) / Provisioned (PTU)

## Evidence
- Model availability screenshots (UK South)
- Quota screenshots (TPM/RPM)
- Approved risk decision if global processing is allowed

## Approvals
- Security Architect:
- Data Protection / GRC:
- Platform Owner:
- Date:
