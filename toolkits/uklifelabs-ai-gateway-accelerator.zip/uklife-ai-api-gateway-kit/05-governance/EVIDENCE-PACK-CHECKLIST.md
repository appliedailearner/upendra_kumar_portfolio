# Evidence Pack Checklist (Audit-ready)

## Network controls
- Palo Alto rules + logging proof
- FortiGate UDR enforcement + traffic proof

## L7 controls
- WAF policy export + rule tuning log
- APIM Products + Subscriptions config
- APIM policy export (validate-jwt, rate limits)

## Private exposure proof
- Backends have no public ingress
- Private endpoints + private DNS evidence

## Observability
- Correlation-id present end-to-end
- Sample trace demonstrating PA -> WAF -> APIM -> backend

## Capacity
- Quotas in UK South documented
- Load test results and p95 latency baseline
